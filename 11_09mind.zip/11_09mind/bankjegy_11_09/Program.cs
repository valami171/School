﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bankjegy_11_09
{
    class Program
    {
        static void Main(string[] args)
        {
            int egy = 0;
            int otven = 0;
            int ketszaz = 0;
            int ezer = 0;
            int ketezer = 0;
            int tizezer = 0;
            int huszezer = 0;
            Console.Write("Add meg az összeget: ");
            int osszeg = Convert.ToInt32(Console.ReadLine());

            while (osszeg > 0)
            {
                if (osszeg >= 20000)
                {
                    huszezer += 1;
                    osszeg = osszeg - 20000;
                }
                else if (osszeg >= 10000)
                {
                    tizezer += 1;
                    osszeg = osszeg - 10000;
                }
                else if (osszeg >= 2000)
                {
                    ketezer += 1;
                    osszeg = osszeg - 2000;
                }
                else if (osszeg >= 1000)
                {
                    ezer += 1;
                    osszeg = osszeg - 1000;
                }
                else if (osszeg >= 200)
                {
                    ketszaz += 1;
                    osszeg = osszeg - 200;
                }
                else if (osszeg >= 50)
                {
                    otven += 1;
                    osszeg = osszeg - 50;
                }
                else if (osszeg >= 1)
                {
                    egy += 1;
                    osszeg = osszeg - 1;
                }
            }

            Console.WriteLine($"Húszezer: {huszezer}, Tízezer: {tizezer}, Kétezer: {ketezer}, Ezer: {ezer}, Ketszaz: {ketszaz}, Ötven: {otven}, Egy: {egy}");
            Console.ReadKey();
        }
    }
}
