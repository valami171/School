﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tömb_11._08
{
    class Program
    {
        static void Main(string[] args)
        {

            // tömb adatszerkezet
            int[] adatok = new int[50];
            Random vel = new Random();


            // töltsük fela az adatok tömböt 0 és 99 közti véletlen számmal

            int db = 0;
            Console.Write("A tömb elemei: ");
            for (int i = 0; i < 50; i++)
            {
                adatok[i] = vel.Next(0,100);
                Console.Write($"{adatok[i]}; ");
                if (adatok[i] == 0)
                {
                    db++;
                }
            }
            Console.WriteLine($"\nA tömbben {db} számú 0 található.");

            Console.ReadKey();
        }
    }
}
