﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _szamtani_sorozat_11_09
{
    class Program
    {
        static void Main(string[] args)
        {

            int szam1, szam2, szam3, k;
            Console.Write("Adj meg egy számot: ");
            szam1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Adj meg egy számot: ");
            szam2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Adj meg egy számot: ");
            szam3 = Convert.ToInt32(Console.ReadLine());

            k = 0;

            if (szam1 < szam2 && szam2 < szam3)
            {
                k = szam2 - szam1;
                if (k == szam3 - szam2)
                {
                    Console.WriteLine($"Növekvő számtani sorozat: {szam1}, {szam2}, {szam3} (kül: +{k})");
                }
                else
                {
                    Console.WriteLine("Ez nem egy számtani sorozat.");
                }
            }

            if (szam1 > szam2 && szam2 > szam3)
            {
                k = szam1 - szam2;
                if (k == szam2 - szam3)
                {
                    Console.WriteLine($"Csökkenő számtani sorozat: {szam1}, {szam2}, {szam3} (kül: -{k})");
                }
                else
                {
                    Console.WriteLine("Ez nem egy számtani sorozat.");
                }
            }
            Console.ReadKey();

        }
    }
}
