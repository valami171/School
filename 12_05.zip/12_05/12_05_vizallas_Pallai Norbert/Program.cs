﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_05_vizallas
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tomb = new int[10];
            Random random = new Random();
            for (int i = 0; i < tomb.Length; i++)
            {
                tomb[i] = random.Next(550, 610);
            }

            Console.WriteLine("a)");
            foreach (var item in tomb)
            {
                Console.Write(item + " ");
            }

            Console.WriteLine("\nb)");
            for (int i = 1; i < tomb.Length; i++)
            {
                if (tomb[i] > tomb[i-1] + 30)
                {
                    Console.WriteLine($"Ez a szám a {i} indexű elem.");
                }
            }

            Console.WriteLine("c)");
            double osszeg = 0;
            int db = 0;
            foreach (var item in tomb)
            {
                osszeg += item;
                db++;
            }
            Console.WriteLine("Az átlag: " + Convert.ToDouble(osszeg)/db);


            Console.WriteLine("d)");
            Console.WriteLine(tomb[0]);
            Console.WriteLine(tomb[tomb.Length-1]);
            Console.WriteLine(tomb[0] - (osszeg/db));
            Console.WriteLine(tomb[tomb.Length-1] - (osszeg / db));

            Console.ReadKey();
        }
    }
}
