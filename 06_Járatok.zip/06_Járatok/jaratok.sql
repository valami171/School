-- 1. feladat
CREATE DATABASE jaratok
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;ű

-- 2. feladat
CREATE TABLE metrok (
    metro int,
    veg1 varchar(30),
    veg2 varchar(30)
);
-- 3. feladat
INSERT INTO metrok VALUES 
(1, "Vörösmarty tér", "Mexikói út"),
(2, "Déli pályaudvar", "Örs vezér tere"),
(3, "Kőbánya-Kispest", "Újpest-központ"),
(4, "Kelenföld vasútállomás", "Nyugati pályaudvar"),
(5, "Rákospalota, Kossuth utca", "Pasaréti tér");

-- 4. feladat
UPDATE metrok
SET veg2 = "Keleti pályaudvar"
WHERE veg2 = "Nyugati pályaudvar";
-- 5. feladat
DELETE FROM metrok
WHERE metro = 5;

-- 6. feladat
SELECT *
FROM `metrok`
-- 7. feladat
SELECT *
FROM metrok
WHERE veg1 LIKE 'K%' OR veg2 LIKE "K%";

-- 8. feladat
SELECT metro
FROM metrok
WHERE veg1 LIKE "%pályaudvar%" OR veg2 LIKE "%pályaudvar%";

-- % bármi lehet (az minket nem érdekel ezesetben)