﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_26
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. feladat
            /*
            Console.WriteLine("Laptop vásárlás");

            int persely = 0;
            int penz;
            Console.Write("Laptop ára: ");
            int laptop = Convert.ToInt32(Console.ReadLine());
            do
            {
                
                Console.Write("Mennyit tesz be a spórolt pénzed van?: ");
                penz = Convert.ToInt32(Console.ReadLine());
                persely = persely + penz;
                Console.WriteLine("Pénzed a perselyben: " + persely);

            } while (persely < laptop);

            Console.WriteLine("Megvan a gyűjtött összeg, mehetünk laptopot vásárolni.");
            */


            // 2. feladat
            // Olvassák be az osztály létszámot.Ellenőrzési szempont (5-36) fő.
            // Ezek után generáljanak véletlenszámokat 1 és 5 között.

            // Számolják ki az osztályátlagot!

            Console.WriteLine("Osztályátlag");
            double lestzam;
            double osszeg = 0;

            Random r = new Random();
            do
            {
                Console.Write("Létszám: ");
                lestzam = Convert.ToDouble(Console.ReadLine());
            } while (lestzam < 5 || lestzam > 36);

            for (int i = 0; i < lestzam; i++)
            {
                double szam = r.Next(1, 5);
                Console.WriteLine(szam);
                osszeg = osszeg + szam;
            }
            Console.WriteLine("Az átlag: " + Math.Round(osszeg / lestzam, 2));
            



            Console.ReadKey();

        }
    }
}
