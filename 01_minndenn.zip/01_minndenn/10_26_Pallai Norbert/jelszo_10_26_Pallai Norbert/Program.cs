﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jelszo_10_26
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.Write("Adj meg egy jelszót: ");
            string jelszo = Console.ReadLine();
            string j;
            do
            {
                Console.Write("Add meg a jelszavad: ");
                j = Console.ReadLine();

            } while (jelszo != j);
            Console.WriteLine("A jelszavad: " + jelszo);

            
            */

            int szam;
            int ossz = 0;
            do
            {
                Console.Write("Adj meg egy számot: ");
                szam = Convert.ToInt32(Console.ReadLine());
                ossz++;

            } while (szam > 100 && szam < 1000);
            Console.WriteLine((ossz-1) +"-szer adtál meg helyes számot.");

            Console.ReadKey();
        }
    }
}
