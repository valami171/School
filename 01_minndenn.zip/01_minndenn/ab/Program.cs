﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ab
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("----- 2. feladat -----");
            
            /*
             int a = 5, b = 7;
            int c, d;
            c = a++ - b--;
            d = ++a - --b;
             */
            
            /*
             Console.WriteLine(c);
            Console.WriteLine(a);
            Console.WriteLine(b);
             */



            Console.WriteLine("----- 3. feladat -----");
            int a = 5, b = 7;
            bool c, d;
            c = (a == b);
            d = ((a+2) == b);

            Console.WriteLine("c: " + c);
            Console.WriteLine("d: " + d);

            Console.ReadKey();


        }
    }
}
