﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gyakorlas_ciklusok_elagazasok
{
    class Program
    {
        static void Main(string[] args)
        {
            char valasz = 'A';
            //string va = "A";
            int zsebpenz = 0; int kap = 0;
            do
            {
                // menü megjelenítése
                Console.WriteLine("MENU");
                Console.WriteLine("=====");
                Console.WriteLine("B: beolvasás");
                Console.WriteLine("V: Vásárlás");
                Console.WriteLine("E: End (kilépés)");
                Console.WriteLine("Választás? (B/V/E): ");

                // válasz beolvasása
                valasz = Convert.ToChar(Console.ReadLine());

                // elágazás a válasz szerint

                switch (valasz)
                {
                    case 'B':
                        {
                            Console.WriteLine("Beolvasás");
                            Console.WriteLine("Mennyi zsebpénzed van? ");
                            kap = Convert.ToInt32(Console.ReadLine());
                            zsebpenz = zsebpenz + kap;
                            Console.WriteLine("Jelenlegi zsebpénz: " + zsebpenz) ;
                            break;
                        }
                    case 'V':
                        {
                            Console.WriteLine("Vásárlás");
                            break;
                        }
                    case 'E':
                        {
                            Console.WriteLine("End (Vége)");
                            break;
                        }
                    // default:
                }
            } while (valasz != 'E');

            Console.WriteLine("Viszlát");

            Console.ReadKey();

        }
    }
}
