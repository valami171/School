﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace festek1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*szoba falai szel1: 5m szel2: 3,4m magasság: 2,6*/
            /*8m2 1 doboz festék 5600 Ft*/
            /*Hány doboz festéket vásároljak? Mennyibe kerül?*/

            double szel1, szel2, mag;

            Console.Write("Kérem a szoba hosszát: ");
            szel1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Kérem a szoba szélességét: ");
            szel2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Kérem a szoba magasságát: ");
            mag = Convert.ToDouble(Console.ReadLine());


            double eredmeny = 2*(szel1 * mag) + 2*(szel2 * mag);
            int doboz = 8, ar = 5600;
            int db = (int)eredmeny / doboz + 1;

            Console.WriteLine($"{eredmeny} négyzetméter a szoba és {db} doboz kell és {db*ar:c0} -ba kerül.");










            Console.ReadKey();
        }
    }
}
