﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eletkor
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Add meg a nevedet: ");
            string nev = Console.ReadLine();

            Console.Write("Add meg a becenevedet: ");
            string becenev = Console.ReadLine();

            Console.Write("Add meg hogy mikor születtél: ");
            int szuletett = Convert.ToInt32(Console.ReadLine());

            Console.Write("Cipőméreted: ");
            int cipo = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Név: {nev}, beceneved: \"{becenev}\"\n");
            Console.WriteLine($"\tÉletkora: {2023-szuletett}");
            Console.WriteLine($"\tCipőméret: \\{cipo}\\");

            Console.ReadKey();

        }
    }
}
