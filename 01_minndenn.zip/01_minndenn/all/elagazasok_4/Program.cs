﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace elagazasok_4
{
    class Program
    {
        static void Main(string[] args)
        {
            // Öszi kedvezmények élelmiszeripari termékekre!
            // a)
            Console.Write("Add meg a termék eredeti árát: ");
            double eredeti = Convert.ToDouble(Console.ReadLine());
            Console.Write("Add meg a termék új árát: ");
            double uj = Convert.ToDouble(Console.ReadLine());
            if (eredeti >= uj)
            {
                Console.WriteLine($"{100 - (uj / eredeti * 100):f1}%-os akció van a CBA-ban.");
            }
            else if (uj > eredeti){
                Console.WriteLine("Nincs semmilyen akció a CBA-ban.");
            }

            // b)
            Console.Write("Add meg a termék eredeti árát: ");
            double eredeti1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Add meg a termék új árát: ");
            double uj1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Add meg a termék eredeti árát: ");
            double eredeti2 = Convert.ToDouble(Console.ReadLine());
            Console.Write("Add meg a termék új árát: ");
            double uj2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine($"{100 - ((uj1 + uj2*3) /(eredeti1 + eredeti2*3))*100:f1}%-ot és {(eredeti1 + eredeti2 * 3) - (uj1 + uj2 * 3)} Forintot sporoltunk a CBA-ban.");


            Console.ReadKey();
        }
    }
}
