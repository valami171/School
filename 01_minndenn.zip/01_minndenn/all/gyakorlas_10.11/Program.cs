﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gyakorlas_10._11
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             Utazunk vonattal 

            Szegedre  200 km
            Győr	160 km
            Cegléd	80 km

            Jagyárak:

            km 25 Ft

            Életkor

            6 év alatt ingyenes

            Diákkedvezménv van-e , ha igen 50%-os jegy
            Felnőtt 100 % jegy

            Nyudijas 50% jegy

            -----------------------------

            Hová utazik : xxxxx
            Hány éves: yyy
            Diákkedvezmény vagy nyugdijas kedvezmény jár-e? (I/N)

            A vonatjegy ára xxxxx-re zzzzz Ft.
             */

            Console.Write("Hova utazol? ");
            string varos = Console.ReadLine();

            Console.Write("Hány éves vagy? ");
            int kor = Convert.ToInt32(Console.ReadLine());

            Console.Write("Kedvezmény van?");
            string kedvezmeny = Console.ReadLine();

            if (varos == "Szeged" && kedvezmeny == "Nem")
            {
                Console.WriteLine($"A vonatjegy ára {varos}-re {200*25} Ft");
            }
            else if (varos == "Szeged" && kedvezmeny == "Igen")
            {
                if (kor< 6)
                {
                    Console.WriteLine($"Ingyen utazohatsz {varos}-re");
                }
                else
                {
                    Console.WriteLine($"A vonatjegy ára {varos}-re {(200 * 25) * 0.5} Ft");
                }
            }




            Console.ReadKey();
        }
    }
}
