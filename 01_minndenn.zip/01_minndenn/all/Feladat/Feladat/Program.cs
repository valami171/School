﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Feladat
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t");
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t");
            Console.BackgroundColor = ConsoleColor.Green;
            Console.WriteLine("\t\t\t\t\t\t\n\t\t\t\t\t\t\n\t\t\t\t\t\t");

            Console.BackgroundColor = ConsoleColor.Black;


            Console.ReadKey();
        }
    }
}
