﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Maradék képzés*/
            /*
              Console.WriteLine("Van 1000 Ft-om, melyből Mars csokoládét szeretnék vásárolni. Egy Mars csokoládé 228 Ft-ba kerül. Hány darab csokoládét tudok venni a pénzemből, és mennyi fog maradni?");
             int penz = 1000;
             int mars = 228;
             Console.WriteLine($"{penz / mars} darab mars szeletet tudok venni és még marad {penz % mars} Forintom.");

             */

            /*Csempe 4m*3m - 1 csempe 60*40cm
             1 doboz 8 csempe
            1 doboz 9800 Ft
            Mennyibe kerül a csempe?
             */

            /*
              int szelesseg = 400 / 60 +1, magassag = 300/ 45 +1;

             int doboz = szelesseg * magassag / 8 + 1;

             Console.WriteLine($"{doboz} dobozra van szükségem, ami {doboz*9800:c0}-ba kerül.");
             */

            const int csempe_sz = 60;
            const int csempe_m = 45;
            const int doboz_db = 8;
            const int doboz_ar = 9800;

            Console.Write("Kérem a helyég szélességét m-ben: ");
            double szel = Convert.ToDouble(Console.ReadLine());
            szel = szel * 100;

            Console.Write("Kérem a helyég magasságát m-ben: ");
            double mag = Convert.ToDouble(Console.ReadLine());
            mag = mag * 100;

            int sor_db = (int)szel / csempe_sz;

            if (!((int)szel % csempe_sz == 0))
            {
                sor_db++;
            }

            Console.WriteLine("Egy sorba rakandó csempék száma: " + sor_db + " db.");







            Console.ReadKey();

        }
    }
}
