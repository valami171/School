﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while_ciklus
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ciklusok - while");
            
            /*
            int i;

            
            for (i = 0; i < 10; i++)
            {
                Console.WriteLine("Pistike");
            }
            */

            /*
            i = 0; 
            while (i<10)
            {
                Console.WriteLine("Pistike");
                i++;
            }
            */

            /*
            int osszeg = 0; int szam = 0;

            while (osszeg < 100)
            {
                Console.Write("Kérek egy számot: ");
                szam = Convert.ToInt32((Console.ReadLine()));
                osszeg = osszeg + szam;
                Console.WriteLine("Összeg: " + osszeg);
            }
            Console.WriteLine("Teljes összeg: " + osszeg);

            */

            // feladat
            // Önnek van 1000 Ft-ja és vásárolgat belőle.
            // A program kérdezze meg mennyit költött?
            // Írja ki a (maradék) rendelkezésre álló pénzt
            // És csinálja ciklusban mindaddig

            // a) amíg van pénze
            // b) amíg a pénze 40 Ft alá nem fogy

            // a)
            int penz = 1000;
            
            while (penz > 0)
            {
                Console.WriteLine($"A pénzed: {penz}");
                Console.Write("Mennyit költöttél?: ");
                int koltott = Convert.ToInt32(Console.ReadLine());
                penz = penz - koltott;
            }
            if (penz < 0)
            {
                Console.WriteLine($"Elfogyott a pénzed. {penz} Ft");
            }

            // b)
            int penz2 = 1000;

            while (penz2 > 40)
            {
                Console.WriteLine($"A pénzed: {penz2}");
                Console.Write("Mennyit költöttél?: ");
                int koltott2 = Convert.ToInt32(Console.ReadLine());
                penz2 = penz2 - koltott2;
            }
            if (penz2 < 40)
            {
                Console.WriteLine($"40 Ft allat van a pénzed. {penz2} Ft");
            }


            int a = 5; int b = 3; int c = 0;
            c = a++ + b++;
            Console.WriteLine("c: " + c);
            c = ++a + ++b;
            Console.WriteLine("c: " + c);

            Console.ReadKey();
        }
    }
}
