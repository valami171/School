﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace gyakorlas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ismétlés");

            // a) beolvasni 2 egész szám 1-50
            // kisebbtől nagyobbik fusson szam, négyzete



            int szam1, szam2;
            Console.Write("Adj meg egy számot: ");
            szam1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Adj meg még egy számot: ");
            szam2 = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("szám \tnégyzete");
            for (int i = szam1; i < szam2+1; i++)
            {
                Console.WriteLine(i + "\t" + i*i);
            }

            // b) olvasson be egy egész számot! a fenti ciklus 1-től a beolvasott számig fusson. Írja ki a számot és a négyzetét!

            // c) olvasson be két egész számot! Határozza meg a kisebbet és a nagyobbat.
            Console.WriteLine("----------------");

            int sz1, sz2;
            Console.Write("Adj meg egy számot: ");
            sz1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Adj meg még egy számot: ");
            sz2 = Convert.ToInt32(Console.ReadLine());

            if (sz1 > sz2)
            {
                Console.WriteLine($"kisebb: {sz2}\n" + $"nagyobb: {sz1}");
                for (int i = sz2; i <= sz1; i++)        //d)
                {
                    Console.WriteLine(i);
                }
            }
            else if (sz1 < sz2)
            {
                Console.WriteLine($"kisebb: {sz1}\n" + $"nagyobb: {sz2}");
                for (int i = sz1; i <= sz2; i++)        // d)
                {
                    Console.WriteLine(i);
                }
            }
            else
            {
                Console.WriteLine($"A két szám egyenlő: {sz1}");
            }

            // d) A kisebb számtól a nagyobb számig fusson a ciklus

            

            // buszjegy
            Console.Write("Hány éves vagy? ");
            int kor = Convert.ToInt32(Console.ReadLine());

            if (kor < 6 && kor > 0)
            {
                Console.WriteLine("Ingyenes jegy.");
            }
            else if (kor < 21 && kor >= 6)
            {
                Console.WriteLine("3500 Ft a jegy.");
            }
            else if (kor >= 21)
            {
                Console.WriteLine("9500 Ft a jegy.");
            }
            else
            {
                Console.WriteLine("Nem értelmezhető adat.");
            }






















            Console.ReadKey();
        }
    }
}
