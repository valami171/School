﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace while_ciklus2
{
    class Program
    {
        static void Main(string[] args)
        {
            // 3.)
            // Olvassunk be egy pozitív egész száot pl.: 9
            // írassuk ki az adott számnál kisebb páros számokat

            /*
            Console.Write("Adj meg egy számot: ");
            int szam = Convert.ToInt32(Console.ReadLine());
            */

            /*
            // for
            for (int i = 1; i < szam; i++)
            {
                if (i % 2 == 0)
                {
                    Console.Write(i + " ");
                }
            }
            

            // while
            int n = 1;
            while (n < szam)
            {
                if (n % 2 == 0)
                {
                    Console.Write(n + " ");
                }
                n++;
            }
            */


            // 4.)
            // Olvassunk be egy egész pozitív számot pl.: 19
            // Irassuk ki az adott számnál kisebb 3-mal osztahtó számokat
            // 3,6,9,12,15,18


            /*
            // for
            for (int i = 1; i < szam; i++)
            {
                if (i % 3 == 0)
                {
                    Console.Write(i + " ");
                }
            }

            Console.WriteLine("\n-------------");

            // while
            int n = 1;
            while (n < szam)
            {
                if (n % 3 == 0)
                {
                    Console.Write(n + " ");
                }
                n++;
            }
            */



            // 5.)
            // Olvassunk be két egész pozitív számot pl.: 19, 23 (23, 19!)
            //írassuk ki a két szám közötti számokat! pl. 19,20,21,22,23
            /*
            Console.Write("Adj meg egy számot: ");
            int szam1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Adj meg még egy számot: ");
            int szam2 = Convert.ToInt32(Console.ReadLine());

            // for
            for (int i = szam1; i <= szam2; i++)
            {
                Console.Write(i + " ");
            }

            Console.WriteLine("\n------------");
            // while
            int n = szam1;
            while (n <= szam2)
            {
                Console.Write(n + " ");
                n++;
            }
            */


            // 6.)
            // Olvassuk be egy pozitív egész számot pl. 18
            // írjuk ki az osztóit
            // 2,3,6,9

            Console.Write("Adj meg egy számot: ");
            int szam3 = Convert.ToInt32(Console.ReadLine());


            // for
            for (int i = 1; i < szam3; i++)
            {
                if (szam3 % i == 0)
                {
                    Console.Write(i + " ");
                }
            }

            Console.WriteLine("\n------------");
            // while
            int n = 1;
            while (n < szam3)
            {
                if (szam3 % n == 0)
                {
                    Console.Write(n + " ");
                }
                n++;
            }


            Console.ReadKey();
        }
    }
}
