﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logikai_kifejezesek
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
             Console.WriteLine("Logika kifejezések");
            // int a = 5, b= 3;
            char a = 'f';
            string b = "Béka";
            Console.Write("A nagyobb e mint B?: ");
            Console.Write("a>b?: ");
             */

            /*
             bool ered = a > b;
            Console.WriteLine(ered); ;
            Console.WriteLine(a>b);
            
             */

            
            
            
            
            
            
            
            
            // FELADATOK

            //1. feladat: Olvassuk be 2 tanuló adatát (név, szulev)
            // nev1, nev2, szulev1, szulev2
            // a) Ugyanabban az évben születtek-e? (== az egyenlőseg vizsgálata) if (szulev1 == szulev2)
            // b) nev1 nevű tanuló idősebb-e mint nev2?
            // c) Irja ki a fiatlabb tanuló nevét és életkorát!


            Console.WriteLine("1. feladat");
            string nev1, nev2;
            int szulev1, szulev2;

            Console.Write("Add meg az első nevet: ");
            nev1 = Console.ReadLine();
            Console.Write("Add meg a második nevet: ");
            nev2 = Console.ReadLine();

            Console.Write($"Add meg az {nev1}-nak/nek az születésévét: ");
            szulev1 = Convert.ToInt32(Console.ReadLine());
            Console.Write($"Add meg az {nev2}-nak/nek az születésévét: ");
            szulev2 = Convert.ToInt32(Console.ReadLine());

            // a)
            bool szul = true;
            if (szulev1 == szulev2)
                Console.WriteLine("a)" + szul);
            else
            {
                szul = false;
                Console.WriteLine("a)" + szul);
            }

            // b)
            bool idosebb = true;
            if (szulev1 < szulev2)
                Console.WriteLine("b)" + idosebb);
            else
            {
                idosebb = false;
                Console.WriteLine("b)" + idosebb);
            }

            // c)
            if (szulev1 > szulev2)
            {
                Console.WriteLine($"c) {nev1} a fiatalabb és {2023 - szulev1} éves.");
            }
            else if (szulev2 > szulev1)
            {
                Console.WriteLine($"c) {nev2} a fiatalabb és {2023 - szulev2} éves.");
            }
            else
            {
                Console.WriteLine($"c) Mindketten {2023 - szulev1} évesek");
            }


            //2f. 
            //   olvasson be két egész számot  (szam1, szam2)
            //   a) ? szam1 > szam2
            //   b) ? szam1 kétszerese nagyobb-e mint szam2
            //   c) szam1 osztható -e (maradék nélkül) szám2vel?
            //   d) valamelyik szám osztható-e (maradék nélkül) a másikkal?


            Console.WriteLine("2. feladat");
            int szam1, szam2;
            Console.Write("Add meg az első számot: ");
            szam1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Add meg a második számot: ");
            szam2 = Convert.ToInt32(Console.ReadLine());

            // a)
            Console.WriteLine("a)" + (szam1 > szam2));
            // b)
            Console.WriteLine("b)" + (szam1*2 > szam2));
            // c )
            Console.WriteLine("c)" + (szam1 % szam2 == 0));
            // d)
            Console.WriteLine("d)" + (szam1 % szam2 == 0 || szam2 % szam1 == 0));



            //3.f
            //   Olvasson be 3 számot!
            //   a) Szerkeszthet-ő belőlük háromszög?
            //   b) Egyenlő oldalú háromszög-e?
            //   c) Derékszögű-e a háromszög?

            int a,b,c;
            Console.Write("Add meg az a oldalt: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Add meg a b oldalt: ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Add meg a c oldalt: ");
            c = Convert.ToInt32(Console.ReadLine());

            // a)
            if (a + b > c && a+c > b && b + c > a) 
                Console.WriteLine("a) Szerkezthető");
            else
                Console.WriteLine("a) Nem szerkeztehtő");

            // b)
            if (a == b || a == c || b == c)
                Console.WriteLine("b) Egyenlő oldalú háromszög.");
            else
                Console.WriteLine("b) Nem egyenlő oldalú háromszög.");

            // c)
            if (a*a+b*b==c*c)
                Console.WriteLine("c) Derékszögű háromszőg");
            else
                Console.WriteLine("c) Nem derékszögű háromszög.");



            Console.ReadKey();
        }
    }
}
