﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ciklusok
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ciklusok");
            // for SZÁMLÁLÓS ciklus
            // for TAB TAB
            /*
            Random r = new Random();
            int gsz;
            for (int i = 1; i <= 5; i = i + 1)
            {
                gsz = r.Next(150, 210);
                Console.Write($"{i}. tanuló magassága {gsz} cm");
                if (gsz < 160)
                {
                    Console.WriteLine("\t\tkicsi vagy");
                }
                else if (gsz > 185)
                {
                    Console.WriteLine("\t\tmagas vagy");
                }
                else
                {
                    Console.WriteLine("");
                }
            }
            */




            // generáljon életlen számot 0-36-ig
            // 1-12 kiirás: első tucat
            // 13-24 kiírás: második tucat
            // 25-36 kiírás: harmadik tucat
            // 0: nulla
            // utána 10-szer futó for ciklusba rakja bele

            Random n = new Random();
            

            for (int i = 1; i < 10; i=i+1)
            {
                int szam = n.Next(0, 36);
                if (szam == 0)
                {
                    Console.WriteLine(szam + " - nulla");
                }
                else if (szam > 1 && szam <= 12)
                {
                    Console.WriteLine(szam + " - első tucat");
                }
                else if (szam > 12 && szam <= 24)
                {
                    Console.WriteLine(szam + " - második tucat");
                }
                else if (szam > 24 && szam <= 36)
                {
                    Console.WriteLine(szam + " - harmadik tucat");
                }
            }

            Console.ReadKey();
        }
    }
}
