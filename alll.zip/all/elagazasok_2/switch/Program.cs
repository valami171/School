﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace @switch
{
    class Program
    {
        static void Main(string[] args)
        {
            // a)
            
            Console.Write("Olvassa be a nap sorszámát (1-7): ");
            int nap = Convert.ToInt32(Console.ReadLine());

            switch(nap)
            {
                case 1:
                    Console.WriteLine("Hétfő");
                    break;
                case 2:
                    Console.WriteLine("Kedd");
                    break;
                case 3:
                    Console.WriteLine("Szerda");
                    break;
                case 4:
                    Console.WriteLine("Csütörtök");
                    break;
                case 5:
                    Console.WriteLine("Péntek");
                    break;
                case 6:
                    Console.WriteLine("Szombat");
                    break;
                case 7:
                    Console.WriteLine("Vasárnap");
                    break;
            }


            // b)
            switch (nap)
            {
                case 1:
                case 2:
                    Console.WriteLine("Hét eleje");
                    break;
                case 3:
                case 4:
                case 5:
                    Console.WriteLine("Hét közepe");
                    break;
                case 6:
                case 7:
                    Console.WriteLine("Hétvége");
                    break;
            }

            

            // 2. feladat
            
            Console.Write("Hány óra van? ");
            int ora = Convert.ToInt32(Console.ReadLine());

            if (5 <= ora &&  ora <= 8)
                Console.WriteLine("Jó reggelt");
            else if (9 <= ora && ora <= 18)
                Console.WriteLine("Jó napot");
            else if (19 <= ora && ora <= 21)
                Console.WriteLine("Jó estét");
            else if (22 <= ora || ora < 4)
                Console.WriteLine("Jó éjszakát");
           

            // 3. feladat
            Console.Write("Add meg a születési évedet: ");
            int szulev = Convert.ToInt32(Console.ReadLine());
            int kor = 2023 - szulev;

            if(kor <= 6 && kor > 0)
                Console.WriteLine("Gyermek");
            else if (kor >= 7 && kor < 22)
                Console.WriteLine("Iskolás");
            else if (kor >= 22 && kor <= 64)
                Console.WriteLine("Felnőtt");
            else if (kor >= 65)
                Console.WriteLine("Nyugdíjas");
            else if (kor <= 0)
                Console.WriteLine("Nem értelmezhető");



            // 4. feladat
            Console.Write("Adj meg egy számot: ");
            int szam1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Adj meg egy számot: ");
            int szam2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Adj meg egy számot: ");
            int szam3 = Convert.ToInt32(Console.ReadLine());

            if (2*(szam1*szam2) > 2*(szam1+szam3) && 2*(szam1 + szam2) > 2*(szam2 + szam3))
                Console.WriteLine($"{szam1} és {szam2 } felhasználásával érjhetjük a lehnagyobb téglalapot: {2 * (szam1 + szam2)}");
            else if (2 * (szam1 + szam3) > 2 * (szam1 + szam2) && 2 * (szam1 + szam3) > 2 * (szam2 + szam3))
                Console.WriteLine($"{szam1} és {szam3 } felhasználásával érjhetjük a lehnagyobb téglalapot: {2 * (szam1 + szam3)}");
            else if (2 * (szam2 + szam3) > 2 * (szam1 + szam3) && 2 * (szam2 + szam3) > 2 * (szam1 + szam2))
                Console.WriteLine($"{szam2} és {szam3 } felhasználásával érjhetjük a lehnagyobb téglalapot: {2 * (szam2 + szam3)}");

            Console.ReadKey();
        }
    }
}
