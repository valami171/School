﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hatultesztelos_ciklus_1019
{
    class Program
    {
        static void Main(string[] args)
        {

            //3.)
            // Olvassunk be egy pozitiv egész számot pl: 9
            // irassuk ki az adott számnál kisebb páros számokat
            //2,4,6,8,

            /*
            int szam;
            do
            {
                Console.Write("Adj meg egy pozitiv egész számot: ");
                szam = Convert.ToInt32(Console.ReadLine());
            } while (szam < 0);
            Console.WriteLine("A szám: " + szam);
            for (int i = 1; i < szam; i++)
            {
                if (i % 2 == 0)
                {
                    Console.Write(i + " ");
                }
            }
            */

            //4.)
            // Olvassunk be egy pozitiv egész számot pl: 19
            // irassuk ki az adott számnál kisebb 3-al osztható számokat
            // 3,6,9,12,15,18,

            /*
            int szam1;
            do
            {
                Console.Write("Adj meg egy pozitiv egész számot: ");
                szam1 = Convert.ToInt32(Console.ReadLine());
            } while (szam1 < 0);
            for (int i = 1; i < szam1; i++)
            {
                if (i % 3 == 0)
                {
                    Console.Write(i + " ");
                }
            }
            */


            //5.)
            // Olvassunk be két pozitiv egész számot pl: 19, 23  (23,19!)
            //irassuk ki a két szám közötti számokat!  Pl: 19,20,21,22,23 

            /*
            int szam2;
            int szam3;
            do
            {
                Console.Write("Adj meg egy pozitív egész számot: ");
                szam2 = Convert.ToInt32(Console.ReadLine());
                Console.Write("Adj meg egy pozitív egész számot: ");
                szam3 = Convert.ToInt32(Console.ReadLine());

            } while (szam2 < 0);
            for (int i = szam2; i <= szam3; i++)
            {
                Console.Write(i + " ");
            }

            */

            //6.) 
            //  Olvassunk be egy pozitiv egész számot pl: 18
            // írjuk ki az osztóit
            // 2,3,5,6,9

            /*
            int szam4;
            do
            {
                Console.Write("Adj meg egy pozitív egész számot: ");
                szam4 = Convert.ToInt32(Console.ReadLine());
            } while (szam4 < 0);
            for (int i = 1; i <= szam4; i++)
            {
                if (szam4 % i == 0)
                {
                    Console.Write(i + " ");
                }
            }
            */

            /*
            7.)
                Olvassa be mennyi zsebpénze van!
                Ebből a büfében vásárolgat
                  1 szendvics 600 Ft
                  1 üditő 250 Ft

                Minden vásárlás után írja ki mennyi pénze maradt. (Ha már nincs elég pénze a termék megvásásrlásához akkor azt is írja ki.

                Pl:
                Mennyi zsebpénze van ? 1500 Ft

                Új vásárlás(1: Szendvics(600 Ft), 2: Üditő(250Ft)  3: Vége): 1
                Maradék zsebpénz: 900Ft

                Új vásárlás(1: Szendvics(600 Ft), 2: Üditő(250Ft) 3: Vége): 1
                Maradék zsebpénz: 300Ft

                Új vásárlás(1: Szendvics(600 Ft), 2: Üditő(250Ft) 3: Vége): 2
                Maradék zsebpénz: 50Ft

                Új vásárlás(1: Szendvics(600 Ft), 2: Üditő(250Ft) 3: Vége): 2
                Nincs elég pénze a termék megvásárlására.
                Maradék zsebpénz: 50Ft

                Új vásárlás(1: Szendvics(600 Ft), 2: Üditő(250Ft) 3: Vége): 3
                Maradék zsebpénz: 50Ft
                Viszontlátásra!
            */

            /*
            int penz;
            do
            {
                Console.Write("Mennyi zsebpénze van? ");
                penz = Convert.ToInt32(Console.ReadLine());
            } while (penz < 0);
            while (penz >= 0)
            {
                Console.Write("Új vásárlás(1: Szendvics(600 Ft), 2: Üditő(250Ft)  3: Vége): ");
                int opcio = Convert.ToInt32(Console.ReadLine());
                
                if (opcio == 1)
                {
                    penz = penz - 600;
                    if (penz <= 0)
                    {
                        Console.WriteLine("Nincs elég pénze a termék megvásárlására.");
                        break;
                    }
                }
                else if (opcio == 2)
                {
                    penz = penz - 250;
                    if (penz <= 0)
                    {
                        Console.WriteLine("Nincs elég pénze a termék megvásárlására.");
                        break;
                    }
                }
                else if (opcio == 3)
                {
                    Console.WriteLine("Viszontlátásra!");
                    break;
                }
                else
                {
                    Console.WriteLine("Az információ nem értelmezhető.");
                    break;
                }
                Console.WriteLine($"Maradék zsebpénz: {penz}");
            }
            */
            int penz;
            bool vege = true;
            do
            {
                Console.Write("Mennyi zsebpénze van? ");
                penz = Convert.ToInt32(Console.ReadLine());
            } while (penz < 0);

            do
            {
                while (vege)
                {
                    Console.Write("Új vásárlás(1: Szendvics(600 Ft), 2: Üditő(250Ft)  3: Vége): ");
                    int opcio = Convert.ToInt32(Console.ReadLine());

                    if (opcio == 1)
                    {
                        if (penz <= 0)
                        {
                            Console.WriteLine("Nincs elég pénze a termék megvásárlására.");
                        }
                        else
                        {
                            penz = penz - 600;
                            Console.WriteLine($"Maradék zsebpénz: {penz}");
                        }
                    }
                    else if (opcio == 2)
                    {
                        if (penz <= 0)
                        {
                            Console.WriteLine("Nincs elég pénze a termék megvásárlására.");
                        }
                        else
                        {
                            penz = penz - 250;
                            Console.WriteLine($"Maradék zsebpénz: {penz}");
                        }
                    }
                    else if (opcio == 3)
                    {
                        Console.WriteLine("Viszontlátásra!");
                        vege = false;
                    }
                    else
                    {
                        Console.WriteLine("Az információ nem értelmezhető.");
                        vege = false;
                    }
                }
            } while (vege);
            


            Console.ReadKey();
        }
    }
}
