﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dowhile1
{
    class Program
    {
        static void Main(string[] args)
        {

            /*
            Console.WriteLine("Hátultesztelős ciklus");
            int jegy;

            do
            {
                Console.Write("Add meg a jegyed: ");
                jegy = Convert.ToInt32(Console.ReadLine());

            } while (jegy < 0 || jegy > 5);

            Console.WriteLine($"A jegyed: {jegy}");

            */

            // kérjen be egy pozitív egész számot és futtasson egy ciklust
            // a beolvasott értéktől tovább még 10 lépést
            //  pl beolvassa -3 nem jó
            //  beolvassa -9 nem jó
            // beolvassa 7 jó
            //  ciklus fut: 7,8,9,... (10db)


            int szam;
            do
            {
                Console.Write("Adj meg egy pozitív számot: ");
                szam = Convert.ToInt32(Console.ReadLine());

            } while (szam < 0);
            for (int i = szam; i <= szam+10; i++)
            {
                Console.WriteLine(i);
            }




            Console.ReadKey();
        }
    }
}
