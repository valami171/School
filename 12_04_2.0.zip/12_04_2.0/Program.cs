﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_04_2._0
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] tomb = new int[20];

            Random random = new Random();

            for (int i = 0; i < tomb.Length; i++)
            {
                tomb[i] = random.Next(-20, 25);
            }

            Console.WriteLine("1. feladat");
            foreach (var item in tomb)
            {
                Console.Write(item + " ");
            }


            Console.WriteLine("\n2. feladat");
            foreach (var item in tomb)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("3. feladat");
            foreach (var item in tomb)
            {
                if (item < 0)
                {
                    Console.Write(item + " ");
                }
            }

            Console.WriteLine("\n4. feladat");
            foreach (var item in tomb)
            {
                if (item > 0 && item % 2 == 0)
                {
                    Console.Write(item + " ");
                }
            }

            Console.WriteLine("\n5. feladat");

            Console.WriteLine(tomb[0]);
            Console.WriteLine(tomb[tomb.Length-1]);


            Console.WriteLine("\n6. feladat");

            for (int i = 1; i < tomb.Length; i++)
            {
                if (i % 2 != 0)
                {
                    Console.Write(i + " ");
                }
            }

            Console.WriteLine("\n7. feladat");
            for (int i = 1; i < tomb.Length; i++)
            {
                if (tomb[i] > tomb[i-1])
                {
                    Console.WriteLine(tomb[i-1] + " " + tomb[i]);
                }
            }

            /*
            Console.WriteLine("8. feladat");
            foreach (var item in tomb)
            {
                if (item < 0)
                {
                    Console.Write(Math.Abs(item) + " ");
                }
            }
            */

            Console.WriteLine("\n9. feladat");
            foreach (var item in tomb)
            {
                if (item <= 5 && item >= -5)
                {
                    Console.Write(item + " ");
                }
            }


            Console.WriteLine("\n10. feladat");
            foreach (var item in tomb)
            {
                if (item < -10 || item > -5)
                {
                    Console.Write(item + " ");
                }
            }


            Console.WriteLine("\n11. feladat");
            foreach (var item in tomb.Reverse())
            {
                Console.Write(item + " ");
            }


            Console.WriteLine("\n12. feladat");
            tomb[0] = tomb[tomb.Length - 1];
            Console.WriteLine(tomb[0]);



            Console.WriteLine("\n13. feladat");


            Console.ReadKey();
        }
    }
}
