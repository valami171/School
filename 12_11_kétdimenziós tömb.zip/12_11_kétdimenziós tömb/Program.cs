﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_11_kétdimenziós_tömb
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Játékos1 neve: ");
            string jatekos1 = Console.ReadLine();
            Console.Write("Játékos2 neve: ");
            string jatekos2 = Console.ReadLine();

            int osszeg1 = 0;
            int osszeg2 = 0;


            Random random = new Random();

            int[,] tomb1 = new int[10, 2];
            for (int i = 0; i < tomb1.GetLength(0); i++)
            {
                for (int k = 0; k < tomb1.GetLength(1); k++)
                {
                    tomb1[i, k] = random.Next(1, 7);

                }

            }

            int[,] tomb2 = new int[10, 2];
            for (int i = 0; i < tomb1.GetLength(0); i++)
            {
                for (int k = 0; k < tomb1.GetLength(1); k++)
                {
                    tomb2[i, k] = random.Next(1, 7);

                }

            }


            int egyenlo = 0;
            Console.Write(jatekos1 + " számai\t\t" + jatekos2 + " számai\n");
            for (int i = 0; i < tomb1.GetLength(0); i++)
            {
                if (tomb1[i,0] == tomb1[i,1])
                {
                    egyenlo = tomb1[i, 0] + tomb1[i, 1] + 20;
                    osszeg1 = egyenlo;
                    Console.Write($"{tomb1[i, 0]} {tomb1[i, 1]}\t\t\t{tomb2[i, 0]} {tomb2[i, 1]}");
                    Console.WriteLine($"{jatekos1} számainak összege: {osszeg1}\t{jatekos2} számainak összege: {osszeg2}");
                }
                else if (tomb1[i, 0] != tomb1[i, 1])
                {
                    osszeg1 = tomb1[i, 0] + tomb1[i, 1];
                    Console.Write($"{tomb1[i, 0]} {tomb1[i, 1]}\t\t\t{tomb2[i, 0]} {tomb2[i, 1]}");
                    Console.WriteLine($"{jatekos1} számainak összege: {osszeg1}\t{jatekos2} számainak összege: {osszeg2}");
                }
                else if (tomb2[i, 0] == tomb2[i, 1])
                {
                    egyenlo = tomb2[i, 0] + tomb2[i, 1] + 20;
                    osszeg2 = egyenlo;
                    Console.Write($"{tomb1[i, 0]} {tomb1[i, 1]}\t\t\t{tomb2[i, 0]} {tomb2[i, 1]}");
                    Console.WriteLine($"{jatekos1} számainak összege: {osszeg1}\t{jatekos2} számainak összege: {osszeg2}");
                }
                else if (tomb1[i, 0] != tomb1[i, 1])
                {
                    osszeg2 = tomb1[i, 0] + tomb1[i, 1];
                    Console.Write($"{tomb1[i, 0]} {tomb1[i, 1]}\t\t\t{tomb2[i, 0]} {tomb1[i, 1]}");
                    Console.WriteLine($"{jatekos1} számainak összege: {osszeg1}\t{jatekos2} számainak összege: {osszeg2}");
                }

                Console.WriteLine();
            }



            Console.ReadKey();

        }
    }
}
