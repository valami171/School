﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12_11_kétdimenziós_tömb
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Játékos1 neve: ");
            string jatekos1 = Console.ReadLine();
            Console.Write("Játékos2 neve: ");
            string jatekos2 = Console.ReadLine();

            int osszeg1 = 0;
            int osszeg2 = 0;


            Random random = new Random();

            int[,] tomb1 = new int[10, 2];
            for (int i = 0; i < tomb1.GetLength(0); i++)
            {
                for (int k = 0; k < tomb1.GetLength(1); k++)
                {
                    tomb1[i, k] = random.Next(1, 7);

                }

            }

            int[,] tomb2 = new int[10, 2];
            for (int i = 0; i < tomb1.GetLength(0); i++)
            {
                for (int k = 0; k < tomb1.GetLength(1); k++)
                {
                    tomb2[i, k] = random.Next(1, 7);

                }

            }

            for (int i = 0; i < tomb1.GetLength(0); i++)
            {
                for (int k = 0; k < tomb1.GetLength(1); k++)
                {
                    Console.WriteLine($"{tomb1[i, k]}");
                }
            }


            Console.ReadKey();

        }
    }
}
