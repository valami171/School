-- 1. feladat
CREATE DATABASE atletika
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci

-- 2. feladat
CREATE TABLE ermek(
    helyezes int,
    orszag varchar(20),
    arany int,
    ezust int,
    bronz int
);

-- 3. feladat
INSERT INTO ermek(helyezes, orszag, arany, ezust, bronz) VALUES
(1, 'Egyesült Államok', 12, 8, 9),
(2, 'Kanada', 4, 2, NULL),
(3, 'Spanyolország', 4, 1, NULL),
(4, 'Jamaica', 3, 5, 3),
(5, 'Kenya', 3, 3, 4),
(6, 'Etiópia', 2, 4, 3)

-- 4. feladat
UPDATE ermek
SET bronz = 4
WHERE orszag = 'Jamaica'

-- 5. feladat
DELETE FROM ermek
WHERE bronz = 0

-- 6. feladat
SELECT *
FROM `ermek`

-- 7. feladat
SELECT *
FROM `ermek`
WHERE ezust >= 4



DROP DATABASE atletika