﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._13
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.Write("Adj meg egy valós számot: ");
            string szam = Console.ReadLine();

            Console.WriteLine("Szám: " + szam);

            for (int i = 0; i < Convert.ToInt32(szam.Split(',')[0]); i++)
            {
                Console.Write("x");
            }
            Console.Write(" | ");
            for (int i = 0; i < Convert.ToInt32(szam.Split(',')[1]); i++)
            {
                Console.Write("y");
            }
            */



            // vélszám

            /*
            Random r = new Random();

            for (int i = 0; i < 20; i++)
            {
                int vszam = r.Next(-10, 10);
                if (vszam >= 1 && vszam <= 5)
                {
                    Console.WriteLine($"jó | {vszam}");
                }
                else
                {
                    Console.WriteLine($"nem jó | {vszam} ");
                }
            }
            */

            /*
            Console.Write("Kérsz sütit? ");
            string valasz = Console.ReadLine();
            int db = 0;
            while (valasz == "igen")
            {
                db += 1;
                Console.Write("Kérsz sütit? ");
                valasz = Console.ReadLine();
            }
            Console.WriteLine($"Süti: {db} db");
            */


            string valasz;
            int db = 0;
            do
            {
                Console.Write("Kérsz sütit? ");
                valasz = Console.ReadLine();
                db += 1;
            } while (valasz == "igen");
            Console.WriteLine($"Süti: {db-1} db");
            
            Console.ReadKey();
        }
    }
}
