-- 1. feladat
CREATE DATABASE muvek
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE regenyek(
    szerzo varchar(20),
    cim varchar(30),
    kiadas int
);

-- 3. feladat
INSERT INTO regenyek(szerzo, cim, kiadas) VALUES
("Agatha Christie","A titokzatos stylesi eset",1920),
("Agatha Christie","A Hét Számlap rejtélye",1929),
("Agatha Christie","Gyilkosság az Orient expresszen",1934),
("Agatha Christie","Rejtély az Antillákon",1964),
("Alex Pavesi","Nyolc nyomozó",2011),
("Juan Francisco Ferrándiz","Az elátkozott föld",2020),
("Sara Faring","A tizedik lány",2022),
("Liane Moriarty","Kilenc idegen",2021),
("John Fowles","A lepkegyűjtő",2022);

-- 4. feladat
UPDATE regenyek
SET kiadas = 2021
WHERE szerzo = "Alex Pavesi Nyolc" AND cim LIKE "Nyolc nyomozó";

-- 5. feladat
SELECT cim FROM regenyek
WHERE szerzo = "Agatha Christie";

-- 6. feladat
SELECT cim FROM regenyek
WHERE szerzo LIKE "A%";

-- 7. feladat
SELECT * FROM regenyek
WHERE cim LIKE "%az%";

-- 8. feladat
SELECT * FROM regenyek
ORDER BY kiadas DESC;

-- 9. feladat
DELETE FROM regenyek
WHERE szerzo NOT LIKE "Agatha Christie";