-- 1. feladat
CREATE DATABASE tenisz
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE noi(
    nev varchar(30),
    kor int,
    pont int,
    helyezes int
);

-- 3. feladat
INSERT INTO noi(nev,kor,pont,helyezes) VALUES
("Adrienn Nagy",21,69,440),
("Amarissa Kiara Toth",20,59,587),
("Anna Bondar",25,797,76),
("Dalma Galfi",24,765,83),
("Fanny Stollar",24,113,420),
("Natalia Szabanin",19,260,248),
("Panna Udvardy",24,713,89),
("Rebeka Stolmar",26,56,600),
("Reka-Luca Jani",31,560,117),
("Timea Babos",29,141,374),
("Vanda Lukacs",30,21,857);

-- 4. feladat
UPDATE noi
SET helyezes = 550
WHERE nev = "Adrienn Nagy";

-- 5. feladat
SELECT nev
FROM noi
WHERE pont > 500;

-- 6. feladat
DELETE FROM noi
WHERE kor > 28;

-- 7. feladat
SELECT nev
FROM noi
WHERE nev LIKE "%r";

-- 8. feladat
SELECT nev
FROM noi
WHERE nev LIKE "_a%" -- _ --> első karakter, % többi része
-- WHERE SUBSTRING(nev, 2, 1) = 'a';

-- 9. feladat
SELECT pont, nev
FROM noi
ORDER BY pont DESC; -- ASC növekvő, DESC csökkenő
