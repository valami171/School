INSERT INTO noi(nev,kor,pont,helyezes) VALUES
("Adrienn Nagy",21,69,440),
("Amarissa Kiara Toth",20,59,587),
("Anna Bondar",25,797,76),
("Dalma Galfi",24,765,83),
("Fanny Stollar",24,113,420),
("Natalia Szabanin",19,260,248),
("Panna Udvardy",24,713,89),
("Rebeka Stolmar",26,56,600),
("Reka-Luca Jani",31,560,117),
("Timea Babos",29,141,374),
("Vanda Lukacs",30,21,857);