CREATE DATABASE agatha DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;

CREATE TABLE regenyek(
    foszereplo varchar(40),
    magyar varchar(50),
    angol varchar(50),
    kiadas int
);

INSERT INTO regenyek VALUES
("Marple","A láthatatlan kéz","The Moving Finger",1942),
("Poirot","Mrs. McGinty halott","Mrs. McGinty's Dead",1952),
(NULL,"És eljő a halál...","Death Comes as the End",1944),
("Marple","Egy marék rozs","A Pocket Full of Rye",1953),
("Poirot","Zátonyok közt","Taken at the Flood",1948),
("Poirot","Nyaraló gyilkosok","Evil Under the Sun",1941),
("Poirot","A fogorvos széke","One, Two, Buckle My Shoe",1940),
("Poirot","Hétvégi gyilkosság","The Hollow",1946),
(NULL,"A titkos ellenfél","The Secret Adversary",1922),
("Marple","Paddington 16.50","4.50 from Paddington",1957),
("Poirot","Temetni veszélyes","After the Funeral",1953),
(NULL,"Az élet súlya","The Burden",1956),
("Poirot","Lord Edgware meghal","Lord Edgware Dies",1933),
(NULL,"Gyöngyöző cián","Sparkling Cyanide",1945),
(NULL,"Miért nem szóltak Evansnak?","Why Didn't They Ask Evans?",1934),
(NULL,"Úti célja ismeretlen","Destination Unknown",1954),
(NULL,"Királyok és kalandorok","The Secret of Chimneys",1925),
("Poirot","Ház a sziklán","Peril at End House",1932),
("Poirot","Öt kismalac","Five Little Pigs",1943),
("Poirot","Poirot karácsonya","Hercule Poirot's Christmas",1938),
(NULL,"Tíz kicsi néger","Ten Little Niggers",1939),
(NULL,"Bagdadba jöttek","They Came to Baghdad",1951),
("Marple","Nem csalás, nem ámítás","They Do It with Mirrors",1952),
("Poirot","Gyilkosság az Orient expresszen","Murder on the Orient Express",1934),
("Marple","A kristálytükör meghasadt","The Mirror Crack’d from Side to Side",1962),
(NULL,"A rózsa és a tiszafa","The Rose and the Yew Tree",1948),
("Poirot","Gyilkosság Mezopotámiában","Murder in Mesopotamia",1936),
(NULL,"Az ijedt szemű lány","Murder on the Links",1923),
("Poirot","A titokzatos Kék Vonat","The Mystery of the Blue Train",1928),
(NULL,"A barna ruhás férfi","The Man in the Brown Suit",1924),
("Poirot","Macska a galambok között","Cat Among the Pigeons",1959),
(NULL,"Végtelen éjszaka","Endless Night",1967),
("Poirot","Függöny: Poirot utolsó esete","Curtain: Poirot's Last Case",1975),
(NULL,"Az óriás kenyere","Giant's Bread",1930),
(NULL,"A frankfurti utas","Passenger to Frankfurt",1970),
("Marple","Holttest a könyvtárszobában","The Body in the Library",1942),
("Poirot","Az órák","The Clocks",1963),
("Poirot","A kutya se látta","Dumb Witness",1937),
(NULL,"A sors kapuja","Postern of Fate",1973),
(NULL,"A gyűlölet őrültje","Murder Is Easy",1939),
("Marple","Szunnyadó gyilkosság","Sleeping Murder",1976),
("Poirot","Tragédia három felvonásban","Three Acts Tragedy",1935),
("Poirot","Halál a felhők fölött","Death in the Clouds",1935),
("Marple","Rejtély az Antillákon","A Caribbean Mystery",1964),
("Marple","Nemezis","Nemesis",1971),
("Poirot","Gloriett a hullának","Dead Man's Folly",1956),
("Poirot","Nyílt kártyákkal","Cards on the Table",1936),
(NULL,"A Hét Számlap rejtélye","The Seven Dials Mystery",1929),
("Poirot","Az Ackroyd-gyilkosság","The Murder of Roger Ackroyd",1926),
("Poirot","Ellopott gyilkosság","Hallowe'en Party",1969),
("Poirot","A titokzatos Négyes","The Big Four",1927),
("Marple","Gyilkosság meghirdetve","A Murder is Announced",1950),
("Poirot","A titokzatos stylesi eset","The Mysterious Affair at Styles",1920),
("Poirot","Találkozás a halállal","Appointment with Death",1938),
("Poirot","Az elefántok nem felejtenek","Elephants Can Remember",1972),
("Marple","Gyilkosság a paplakban","The Murder at the Vicarage",1930),
(NULL,"Távol telt tőled tavaszom","Absent in the Spring",1944),
(NULL,"Bűbájos gyilkosok","The Pale Horse",1961),
(NULL,"Befejezetlen portré","Unfinished Portrait",1934),
("Poirot","Cipruskoporsó","Sad Cypress",1940),
(NULL,"A Sittaford-rejtély","The Sittaford Mystery",1931),
(NULL,"Ferde ház","Crooked House",1949),
("Poirot","Harmadik lány","Third Girl",1966),
("Poirot","Az ABC-gyilkosságok","The ABC Murders",1936),
("Poirot","Halál a Níluson","Death on the Nile",1938),
(NULL,"Balhüvelykem bizsereg...","By the Pricking of My Thumbs",1968),
("Poirot","Gyilkosság a diákszállóban","Hickory, Dickory, Dock",1955),
(NULL,"Az alibi","Ordeal by Innocence",1958),
(NULL,"A lányom mindig a lányom","A Daughter's a Daughter",1952),
(NULL,"N vagy M","N or M?",1941),
(NULL,"Éjféltájt","Towards Zero",1944),
("Marple","A Bertram Szálló","At Bertram's Hotel",1965);


/*
SUM(mezőnév)
AVG(mezőnév)
MIN(mezőnév)
MAX(mezőnév)
COUNT(*)
*/


-- 1. feladat: Írassuk ki, hány regény van az adatbázisban!
SELECT COUNT(*) AS "Regények száma" FROM regenyek;

-- 2. Írassuk ki, az első regény kiadásának évét!
SELECT MIN(kiadas) FROM regenyek;   -- csak az év



-- 3. Írassuk ki, az utolsó regény kiadásának évét!
SELECT MAX(kiadas) FROM regenyek;

-- 4. Írassuk ki, az első Poirot regény minden adatát!
SELECT * FROM  regenyek             -- minden adatot
WHERE foszereplo LIKE "Poirot"
ORDER BY kiadas ASC
LIMIT 1;

-- 5. Írassuk ki, az első 3 regény magyar címét és kiadásának évét az év szerint növekvő sorrendben!
SELECT magyar, kiadas FROM regenyek
ORDER BY kiadas ASC
LIMIT 3;