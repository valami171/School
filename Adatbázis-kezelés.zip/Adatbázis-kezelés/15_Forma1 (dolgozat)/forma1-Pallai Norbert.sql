-- 1. feladat
CREATE DATABASE forma1
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE palyak(
    nev varchar(50),
    tipus varchar(50),
    hossz float,
    helyszin varchar(50),
    orszag varchar(50),
    futamszam int,
    eldol bit
);


-- 3. feladat
INSERT INTO palyak(nev, tipus, hossz, helyszin, orszag, futamszam, eldol) VALUES
("Adelaide Street Circuit","városi",3.78,"Adelaide","Ausztrália",11,1),
("Ain-Diab Circuit","országúti",7.618,"Casablanca","Marokkó",1,1),
("Aintree Motor Racing Circuit","országúti",4.828,"Aintree","Egyesült Királyság",5,0),
("Algarve International Circuit","versenypálya",4.653,"Portimão","Portugália",2,0),
("Autódromo do Estoril","versenypálya",4.36,"Estoril","Portugália",13,1),
("Autodromo Enzo e Dino Ferrari","versenypálya",4.909,"Imola","Olaszország",29,0),
("Autódromo Hermanos Rodríguez","versenypálya",4.304,"Mexikóváros","Mexikó",21,1),
("Autódromo Internacional do Rio de Janeiro","versenypálya",5.031,"Rio de Janeiro","Brazília",10,0),
("Autodromo Internazionale del Mugello","versenypálya",5.245,"Scarperia e San Piero","Olaszország",1,0),
("Autódromo José Carlos Pace","versenypálya",4.309,"São Paulo","Brazília",38,1),
("Autódromo Juan y Oscar Gálvez","versenypálya",4.259,"Buenos Aires","Argentína",20,0),
("Autodromo Nazionale di Monza","versenypálya",5.793,"Monza","Olaszország",71,1),
("AVUS","városi",8.3,"Berlin","Németország",1,0),
("Bahrain International Circuit","versenypálya",5.412,"Szahír","Bahrein",18,0),
("Baku City Circuit","városi",6.003,"Baku","Azerbajdzsán",5,0),
("Brands Hatch Circuit","versenypálya",3.703,"West Kingsdown","Egyesült Királyság",14,0),
("Buddh International Circuit","versenypálya",5.141,"Greater Noida","India",3,1),
("Bugatti Circuit","versenypálya",4.43,"Le Mans","Franciaország",1,0),
("Caesars Palace Grand Prix Circuit","városi",3.65,"Las Vegas","Amerikai Egyesült Államok",2,1),
("Circuit Bremgarten","országúti",7.208,"Bern","Svájc",5,1),
("Circuit de Barcelona-Catalunya","versenypálya",4.675,"Montmeló","Spanyolország",31,0),
("Circuit de Charade","országúti",8.055,"Saint-Genès-Champanelle","Franciaország",4,0),
("Circuit de Dijon-Prenois","versenypálya",3.886,"Prenois","Franciaország",6,0),
("Circuit de Monaco","városi",3.337,"Monte-Carlo","Monaco",67,0),
("Circuit de Montjuïc","városi",3.791,"Barcelona","Spanyolország",4,0),
("Circuit de Nevers Magny-Cours","versenypálya",4.411,"Magny-Cours","Franciaország",18,1),
("Circuit de Pedralbes","városi",6.316,"Barcelona","Spanyolország",2,1),
("Circuit de Reims-Gueux","országúti",8.302,"Gueux","Franciaország",11,0),
("Circuit de Spa-Francorchamps","versenypálya",7.004,"Spa","Belgium",54,1),
("Circuit Gilles-Villeneuve","városi",4.361,"Montréal","Kanada",40,1),
("Circuit Mont-Tremblant","versenypálya",4.265,"Mont-Tremblant","Kanada",2,0),
("Circuit of the Americas","versenypálya",5.513,"Austin","Amerikai Egyesült Államok",9,1),
("Circuit Paul Ricard","versenypálya",5.842,"Le Castellet","Franciaország",17,0),
("Circuit Zandvoort","versenypálya",4.259,"Zandvoort","Hollandia",31,0),
("Circuit Zolder","versenypálya",4.262,"Heusden-Zolder","Belgium",10,0),
("Circuito da Boavista","városi",7.775,"Porto","Portugália",2,0),
("Circuito de Monsanto","városi",5.44,"Lisszabon","Portugália",1,0),
("Circuito Permanente de Jerez","versenypálya",4.428,"Jerez de la Frontera","Spanyolország",7,1),
("Circuito Permanente del Jarama","versenypálya",3.404,"San Sebastián de los Reyes","Spanyolország",9,0),
("Complexe Européen de Nivelles-Baulers","versenypálya",3.724,"Nivelles","Belgium",2,0),
("Dallas Fair Park","városi",3.901,"Dallas","Amerikai Egyesült Államok",1,0),
("Detroit Street Circuit","városi",4.168,"Detroit","Amerikai Egyesült Államok",7,0),
("Donington Park","versenypálya",4.02,"Castle Donington","Egyesült Királyság",1,0),
("Fuji Speedway","versenypálya",4.563,"Oyama","Japán",4,1),
("Hockenheimring","versenypálya",4.574,"Hockenheim","Németország",37,0),
("Hungaroring","versenypálya",4.381,"Mogyoród","Magyarország",36,1),
("Igora Drive Autodrome","versenypálya",4.086,"Szosznovo","Oroszország",0,0),
("Indianapolis Motor Speedway","versenypálya",4.192,"Speedway","Amerikai Egyesült Államok",19,0),
("Isztambul Park","versenypálya",5.338,"Isztambul","Törökország",9,0),
("Jeddah Street Circuit","városi",6.174,"Dzsidda","Szaúd-Arábia",2,0),
("Korea International Circuit","versenypálya",5.615,"Jongam","Dél-Korea",4,0),
("Kyalami Grand Prix Circuit","versenypálya",4.261,"Midrand","Dél-afrikai Köztársaság",20,1),
("Las Vegas Street Circuit","városi",6.12,"Las Vegas","Amerikai Egyesült Államok",0,0),
("Long Beach Street Circuit","városi",3.275,"Long Beach","Amerikai Egyesült Államok",8,0),
("Losail International Circuit","versenypálya",5.38,"Loszaíl","Katar",1,0),
("Melbourne Grand Prix Circuit","városi",5.303,"Melbourne","Ausztrália",24,0),
("Miami International Autodrome","városi",5.41,"Miami Gardens","Amerikai Egyesült Államok",0,0),
("Mosport International Raceway","versenypálya",3.957,"Bowmanville","Kanada",8,0),
("Nürburgring","versenypálya",5.148,"Nürburg","Németország",41,1),
("Pescara Circuit","országúti",25.8,"Pescara","Olaszország",1,0),
("Phoenix Street Circuit","városi",3.72,"Phoenix","Amerikai Egyesült Államok",3,0),
("Prince George Circuit","versenypálya",3.92,"East London","Dél-afrikai Köztársaság",3,1),
("Red Bull Ring","versenypálya",4.318,"Spielberg","Ausztria",35,1),
("Riverside International Raceway","versenypálya",5.271,"Moreno Valley","Amerikai Egyesült Államok",1,0),
("Rouen-Les-Essarts","országúti",6.542,"Orival","Franciaország",5,0),
("Scandinavian Raceway","versenypálya",4.031,"Anderstorp","Svédország",6,0),
("Sebring Raceway","országúti",8.356,"Sebring","Amerikai Egyesült Államok",1,1),
("Sepang International Circuit","versenypálya",5.543,"Sepang","Malajzia",19,0),
("Shanghai International Circuit","versenypálya",5.451,"Sanghaj","Kína",16,0),
("Silverstone Circuit","versenypálya",5.891,"Silverstone","Egyesült Királyság",56,1),
("Singapore Street Circuit","városi",5.063,"Szingapúr","Szingapúr",12,0),
("Sochi Autodrom","versenypálya",5.848,"Sziriusz","Oroszország",8,0),
("Suzuka International Racing Course","versenypálya",5.807,"Szuzuka","Japán",31,1),
("TI Circuit Aida","versenypálya",3.703,"Mimaszaka","Japán",2,1),
("Valencia Street Circuit","városi",5.419,"Valencia","Spanyolország",5,0),
("Watkins Glen International","versenypálya",5.43,"Watkins Glen","Amerikai Egyesült Államok",20,1),
("Yas Marina Circuit","versenypálya",5.281,"Abu-Dzabi","Egyesült Arab Emírségek",13,1);


-- 4. feladat
INSERT INTO palyak(nev, tipus, hossz, helyszin, orszag, futamszam, eldol) VALUES
("Zeltweg Airfield","országúti",3.186,"Zeltweg","Ausztria",1,0);

-- 5. feladat
UPDATE palyak
SET tipus = "országúti"
WHERE nev LIKE "AVUS";

-- 6. feladat
SELECT nev, orszag FROM palyak
WHERE eldol = TRUE;

-- 7. feladat
SELECT nev, hossz FROM palyak
WHERE helyszin LIKE "_____i%";

-- 8. feladat
SELECT * FROM palyak
WHERE helyszin LIKE "B%";

-- 9. feladat
SELECT nev, helyszin FROM palyak
WHERE futamszam > 15
ORDER BY futamszam DESC;

-- 10. feladat
SELECT nev, futamszam FROM palyak
WHERE hossz > 6 AND tipus LIKE "versenypálya"
ORDER BY futamszam ASC;