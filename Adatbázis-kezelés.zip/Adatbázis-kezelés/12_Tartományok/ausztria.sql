-- 1. feladat
CREATE DATABASE ausztria
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE tartomanyok(
    tartomany varchar(30),
    szekhely varchar(30),
    nepesseg int,
    terulet int,
    varosok int,
    mas int
);

-- 3. feladat
INSERT INTO tartomanyok(tartomany, szekhely, nepesseg, terulet, varosok, mas) VALUES
("Burgenland","Kismarton",297583,3965,13,171),
("Karintia","Klagenfurt",564513,9537,17,132),
("Alsó-Ausztria","Sankt Pölten",1698796,19180,76,573),
("Felső-Ausztria","Linz",1505140,11983,32,438),
("Salzburg","Salzburg",560710,7155,11,119),
("Stájerország","Graz",1252922,16399,35,286),
("Tirol","Innsbruck",764102,12648,10,277),
("Vorarlberg","Bregenz",401674,2602,5,96),
("Bécs","Bécs",1931593,415,1,1);

-- 4. feladat
UPDATE tartomanyok
SET varosok = 11
WHERE tartomany LIKE "Tirol";

-- 5. feladat
SELECT MAX(nepesseg) FROM tartomanyok;

-- 6. feladat
SELECT MIN(terulet) FROM tartomanyok;

-- 7. feladat
SELECT MAX(varosok) FROM tartomanyok;

-- 8. feladat
SELECT AVG(nepesseg) FROM tartomanyok;

-- 9. feladat
SELECT SUM(terulet) FROM tartomanyok
WHERE varosok >= 30;

-- 10. feladat
SELECT COUNT(*) AS "tartományok száma" FROM tartomanyok;