INSERT INTO tartomanyok(tartomany,szekhely,nepesseg,terulet,varosok,mas) VALUES
("Burgenland","Kismarton",297583,3965,13,171),
("Karintia","Klagenfurt",564513,9537,17,132),
("Alsó-Ausztria","Sankt Pölten",1698796,19180,76,573),
("Felső-Ausztria","Linz",1505140,11983,32,438),
("Salzburg","Salzburg",560710,7155,11,119),
("Stájerország","Graz",1252922,16399,35,286),
("Tirol","Innsbruck",764102,12648,10,277),
("Vorarlberg","Bregenz",401674,2602,5,96),
("Bécs","Bécs",1931593,415,1,1);