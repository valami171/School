
-- 1. feladat
CREATE DATABASE ajtok
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE ajtok(
    lakas varchar(1),
    tipus varchar(30),
    ar int,
    db int,
    szelesseg int,
    magassag int,
    kava int
);

INSERT INTO ajtok VALUES
("A","Arnold",84900,3,810,2080,120),
("A","Kinga",94900,2,750,2080,120),
("A","Viola",79900,2,700,2080,120),
("A","Miksa",94900,1,860,2080,200),
("B","Detre",124900,2,750,2080,120),
("B","Kinga",94900,2,710,2080,120),
("B","Viola",79900,3,820,2080,120),
("B","Miksa",94900,2,860,2090,200),
("C","Viola",79900,4,800,2080,120),
("C","Arnold",84900,1,820,2080,200),
("D","Arnold",84900,3,860,2080,120),
("D","Kinga",94900,2,750,2080,120),
("D","Viola",79900,2,700,2080,120),
("D","Miksa",94900,1,860,2090,200),
("E","Detre",124900,2,760,2090,120),
("E","Viola",79900,1,820,2090,120),
("E","Miksa",94900,2,850,2090,205),
("F","Viola",79900,4,800,2080,120),
("F","Arnold",84900,1,820,2080,205),
("G","Arnold",84900,2,815,2085,120),
("G","Detre",124900,2,825,2085,120),
("G","Kinga",94900,2,765,2085,120),
("G","Miksa",94900,2,865,2085,205),
("H","Arnold",84900,3,810,2085,120),
("H","Kinga",94900,2,750,2085,120),
("H","Viola",79900,2,700,2085,120),
("H","Miksa",94900,1,860,2085,205);


-- Adjuk meg a G lakás rendeléseit!
SELECT lakas, db FROM ajtok
WHERE lakas LIKE "G";

-- Csoportosíts a káva mérete szerint!
SELECT kava FROM ajtok
GROUP BY kava

-- Mennyi volt az egy ajtóból rendelt maximum!
SELECT MAX(db) FROM ajtok

-- Melyik ajtóból rendelték a legtöbbet!
SELECT tipus, COUNT(*)FROM ajtok
GROUP BY tipus
ORDER BY db DESC
LIMIT 1;

-- Hány Arnold ajtót rendeltek?
SELECT COUNT(*) AS "Arnold" FROM ajtok
WHERE tipus LIKE "Arnold";

-- Listázd ki azokat a lakásokat, ahol a fizetendő összeg több, mint 350 ezer forint
SELECT tipus FROM ajtok
WHERE ar > 350000;

-- Add meg, melyik ajtótípusból hányat vettek!
SELECT tipus, COUNT(*)FROM ajtok
GROUP BY tipus
ORDER BY COUNT(*) DESC;

-- Add meg azokat a lakásokat, ahol legalább 8 ajtót rendeltek.
SELECT lakas, SUM(db) FROM ajtok
GROUP BY lakas
HAVING SUM(db) >= 8;


-- Hány lakásba rendeltek Detre ajtót?
SELECT COUNT(*) FROM ajtok
WHERE tipus LIKE "Detre";


-- Adja meg a C lakás rendeléseit!
SELECT * FROM ajtok
WHERE lakas LIKE "C";

-- Hány rendelést adtak le!
SELECT COUNT(*) FROM ajtok

-- Hány ajtót rendeltek!
SELECT SUM(db) FROM ajtok

-- Adjuk meg azokat az ajtókat, amelyekből legalább 12-t rendeltek!
SELECT tipus, SUM(db) FROM ajtok
GROUP BY tipus
HAVING SUM(db) >= 12;

-- Adjuk meg azokat a lakásokat, ahol legalább 4 különböző ajtótípust rendeltek! Rendezze ár szerint csökkenően!
SELECT lakas, COUNT(*), ar FROM ajtok
GROUP BY lakas
HAVING COUNT(*) >= 4
ORDER BY ar DESC;