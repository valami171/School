-- 1. feladat
CREATE DATABASE leggyorsabb
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci

-- 2. feladat
CREATE TABLE allatok(
    faj varchar(20),
    sebesseg float
);

-- 3. feladat
INSERT INTO allatok(faj, sebesseg) VALUES
('gepárd', 120),
('villásszarvú antilop', 88.5),
('dél-afrikai gazella', 86),
('kék gnú', 80.5),
('oroszlán', 80.5),
('indiai antilop' ,80.5),
('mezei nyúl', 80),
('agár', 74),
('jackrabbit', 72),
('afrikai vadkutya', 71)

-- 4. feladat
UPDATE allatok
SET sebesseg = 88
WHERE faj = 'dél-afrikai gazella'

-- 5. feladat
DELETE FROM allatok
WHERE sebesseg < 80

-- 6. feladat
SELECT *
FROM allatok

-- 7. feladat
SELECT *
FROM `allatok`
WHERE sebesseg > 85