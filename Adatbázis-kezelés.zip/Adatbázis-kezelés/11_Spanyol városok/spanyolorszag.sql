-- 1. feladat
CREATE DATABASE spanyolorszag
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE varosok(
    varos varchar(30),
    lakossag int,
    tartomany varchar(30)
);

-- 3. feladat
INSERT INTO varosok(varos, lakossag, tartomany) VALUES
("A Coruña",243320,"Galicia"),
("Albacete",161508,"Kasztília-La Mancha"),
("Alcalá de Henares",201380,"Madrid"),
("Alcobendas",104118,"Madrid"),
("Alcorcón",164633,"Madrid"),
("Algeciras",112937,"Andalúzia"),
("Alicante",322431,"Valencia"),
("Almería",185309,"Andalúzia"),
("Avilés",83538,"Asztúria"),
("Badajoz",143748,"Extremadura"),
("Badalona",221520,"Katalónia"),
("Barakaldo",95640,"Baszkföld"),
("Barcelona",1605602,"Katalónia"),
("Bilbao",354145,"Baszkföld"),
("Burgos",173676,"Kasztília és León"),
("Cáceres",90218,"Extremadura"),
("Cádiz",130561,"Andalúzia"),
("Cartagena",208609,"Murcia"),
("Castellón de la Plana",172110,"Valencia"),
("Ceuta",75861,"Ceuta"),
("Chiclana de la Frontera",72364,"Andalúzia"),
("Ciudad Real",70124,"Kasztília-La Mancha"),
("Córdoba",322867,"Andalúzia"),
("Cornellà de Llobregat",84289,"Katalónia"),
("Coslada",83233,"Madrid"),
("Donostia-San Sebastián",183308,"Baszkföld"),
("Dos Hermanas",114672,"Andalúzia"),
("El Ejido",75969,"Andalúzia"),
("El Puerto de Santa María",83101,"Andalúzia"),
("Elche",219032,"Valencia"),
("Ferrol",76399,"Galicia"),
("Fuenlabrada",193715,"Madrid"),
("Funchal",96893,"Madeira"),
("Gandia",74827,"Valencia"),
("Getafe",156320,"Madrid"),
("Getxo",82327,"Baszkföld"),
("Gijón",274472,"Asztúria"),
("Girona",89890,"Katalónia"),
("Granada",237929,"Andalúzia"),
("Guadalajara",75493,"Kasztília-La Mancha"),
("Huelva",145763,"Andalúzia"),
("Jaén",116769,"Andalúzia"),
("Jerez de la Frontera",199544,"Andalúzia"),
("L’Hospitalet de Llobregat",248150,"Katalónia"),
("Las Palmas de Gran Canaria",377056,"Kanári-szigetek"),
("Las Rozas de Madrid",75719,"Madrid"),
("Leganés",182471,"Madrid"),
("León",136985,"Kasztília és León"),
("Lleida",125677,"Katalónia"),
("Logroño",147036,"La Rioja"),
("Lorca",89936,"Murcia"),
("Lugo",93450,"Galicia"),
("Madrid",3128600,"Madrid"),
("Málaga",560631,"Andalúzia"),
("Manresa",71772,"Katalónia"),
("Marbella",125519,"Andalúzia"),
("Mataró",118748,"Katalónia"),
("Móstoles",206301,"Madrid"),
("Murcia",416996,"Murcia"),
("Orihuela",77979,"Valencia"),
("Ourense",108137,"Galicia"),
("Oviedo",214883,"Asztúria"),
("Palencia",82263,"Kasztília és León"),
("Palma de Mallorca",375048,"Baleár-szigetek"),
("Pamplona",195769,"Navarra"),
("Parla",95087,"Madrid"),
("Pontevedra",80096,"Galicia"),
("Pozuelo de Alarcón",79581,"Madrid"),
("Reus",101767,"Katalónia"),
("Roquetas de Mar",71740,"Andalúzia"),
("Rubí",70006,"Katalónia"),
("Sabadell",200545,"Katalónia"),
("Salamanca",159754,"Kasztília és León"),
("San Cristóbal de La Laguna",142161,"Kanári-szigetek"),
("San Fernando",93544,"Andalúzia"),
("Sant Boi de Llobregat",81368,"Katalónia"),
("Sant Cugat del Vallès",73774,"Katalónia"),
("Santa Coloma de Gramenet",119056,"Katalónia"),
("Santa Cruz de Tenerife",223148,"Kanári-szigetek"),
("Santander",182926,"Kantábria"),
("Santiago de Compostela",93458,"Galicia"),
("Sevilla",805525,"Andalúzia"),
("Talavera de la Reina",83793,"Kasztília-La Mancha"),
("Tarragona",131158,"Katalónia"),
("Telde",97525,"Kanári-szigetek"),
("Terrassa",199817,"Katalónia"),
("Toledo",77601,"Kasztília-La Mancha"),
("Torrejón de Ardoz",112114,"Madrid"),
("Torrent",74616,"Valencia"),
("Torrevieja",92034,"Valencia"),
("Valencia",852234,"Valencia"),
("Valladolid",319943,"Kasztília és León"),
("Vigo",293255,"Galicia"),
("Vitoria-Gasteiz",227568,"Baszkföld");

-- 4. feladat
DELETE FROM varosok
WHERE varos LIKE "Funchal";

-- 5. feladat
INSERT INTO varosok(varos, lakossag, tartomany) VALUES
("Zaragoza", 649181, "Aragónia");

-- 6. feladat
UPDATE varosok
SET lakossag = 704414
WHERE varos LIKE "Sevilla";

-- 7. feladat
SELECT varos, lakossag FROM varosok
WHERE tartomany LIKE "Galicia";

-- 8. feladat
SELECT varos FROM varosok
WHERE varos LIKE "% %";

-- 9. feladat
SELECT varos FROM varosok
WHERE tartomany LIKE "L%";

-- 10. feladat
SELECT varos, tartomany FROM varosok
WHERE lakossag > 500000;