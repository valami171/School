-- 1. feladat
CREATE DATABASE autok
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci

-- 2. feladat
CREATE TABLE autok(
    rendszam varchar(9),
    marka varchar(20),
    tulajdonos varchar(20),
    ar int,
    uj bit
);

-- 3. feladat
INSERT INTO autok(rendszam, marka, tulajdonos, ar, uj) VALUES
('AA-BC-123', 'Suzuki', 'Kis Pál', 8000000, 1),
('BB-CE-249', 'Renault', 'Nagy Péter', 2500000, 0),
('EE-AB-124', 'Suzuki', 'Szabó János', 3000000, 0),
('CC-AC-123', 'Audi', 'Kovács Dezső', 4200000, 0),
('BB-AC-115', 'BMW', 'Juhász Emese', 10300000, 1);

-- 4. feladat
UPDATE autok
SET ar = 7800000
WHERE tulajdonos = 'Kis Pál'

-- 5. feladat
DELETE FROM autok
WHERE tulajdonos = 'Kovács Dezső'

-- 6. feladat
SELECT *
FROM `autok`

-- 7. feladat
SELECT *
FROM autok
WHERE uj = true

-- 8. feladat
DROP DATABASE autok -- -> kitöröljük az autók adatbázist