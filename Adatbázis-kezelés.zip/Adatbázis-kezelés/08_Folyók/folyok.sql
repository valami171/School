-- 1. feladat
CREATE DATABASE folyok
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE europai(
    nev varchar(10),
    hossz int
);

-- 3. feladat
INSERT INTO europai(nev, hossz) VALUES
("Duagava", 1020),
("Dnyeper", 2290),
("Dnyeszter", 1362),
("Don", 1950),
("Duna", 1750),
("Elba", 1091),
("Rajna", 1320),
("Urál", 2428),
("Visztula", 1047),
("Volga", 3692);

-- 4. feladat
UPDATE europai
SET hossz = 2860
WHERE nev = "Duna";

-- 5. feladat
SELECT nev FROM europai
WHERE hossz > 1500;

-- 6. feladat
SELECT nev FROM europai
WHERE nev LIKE "D%";

-- 7. feladat
SELECT nev FROM europai
WHERE nev LIKE "%n%";

-- 8. feladat
SELECT hossz, nev FROM europai
ORDER BY hossz DESC;

-- 9. feladat
DELETE FROM europai
WHERE nev LIKE "%na";