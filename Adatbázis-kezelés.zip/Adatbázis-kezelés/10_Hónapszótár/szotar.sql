-- 1. feladat
CREATE DATABASE szotar
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE honapok(
    magyar varchar(10),
    olasz varchar(10),
    francia varchar(10)
);

-- 3. feladat
INSERT INTO honapok(magyar, olasz, francia) VALUES
("január","gennaio","janvier"),
("február","febbraio","février"),
("március","marzo","mars"),
("április","april","avril"),
("május","maggio","mai"),
("június","giugno","juin"),
("július","luglio","juillet"),
("augusztus","agosto","août"),
("szeptember","settembre","septembre"),
("október","ottobre","octobre"),
("november","novembre","novembre"),
("december","dicembre","décembre"),
("hétfő","lunedi","lundi");

-- 4. feladat
DELETE FROM honapok
WHERE magyar LIKE "hétfő";

-- 5. feladat
UPDATE honapok
SET olasz = "aprile"
WHERE magyar LIKE "április";

-- 6. feladat
select * FROM honapok
WHERE magyar = "március";

-- 7. feladat
select * FROM honapok
WHERE magyar LIKE "december" OR magyar LIKE "január" OR magyar LIKE "február";

-- 8. feladat
SELECT * FROM honapok
WHERE francia LIKE "j%";

-- 9. feladat
SELECT * FROM honapok
WHERE olasz LIKE "%gi%";

-- 10. feladat
SELECT * FROM honapok
WHERE magyar OR olasz OR francia LIKE "%br%";