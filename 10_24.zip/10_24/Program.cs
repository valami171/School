﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10_24
{
    class Program
    {
        static void Main(string[] args)
        {
            // 1. feladat
            /*
            Console.Write("Adj meg egy számot -80 ás 80 között: ");
            int szam = Convert.ToInt32(Console.ReadLine());

            if (szam < 0)
            {
                for (int i = szam; i > -80; i--)
                {
                    Console.Write("-");
                }
            }
            else if (szam > 0)
            {
                for (int i = szam; i < 80; i++)
                {
                    Console.Write("+");
                }
            }
            */

            // 2. feladat
            /*
            Console.Write("Adj meg egy számot -80 és 80 között: ");
            int szam1 = Convert.ToInt32(Console.ReadLine());

            while (szam1 != 0)
            {
                if (szam1 < 0)
                {
                    for (int i = szam1; i > -80; i--)
                    {
                        Console.Write("-");
                    }
                }
                else if (szam1 > 0)
                {
                    for (int i = szam1; i < 80; i++)
                    {
                        Console.Write("+");
                    }
                }
                Console.Write("\nAdj meg egy számot: ");
                szam1 = Convert.ToInt32(Console.ReadLine());
            }
            */
            /*
            int szam1;
            do
            {
                Console.Write("\nAdj meg egy számot -80 és 80 között: ");
                szam1 = Convert.ToInt32(Console.ReadLine());

                if (szam1 < 0)
                {
                    for (int i = szam1; i > -80; i--)
                    {
                        Console.Write("-");
                    }
                }
                else if (szam1 > 0)
                {
                    for (int i = szam1; i < 80; i++)
                    {
                        Console.Write("+");
                    }
                }

            } while (szam1 != 0);
            Console.WriteLine("Vége");
            */


            int szam1;
            do
            {
                Console.Write("\nAdj meg egy számot: ");
                szam1 = Convert.ToInt32(Console.ReadLine());

                if (szam1 < 0)
                {
                    for (int i = 1; i >= szam1; i--)
                    {
                        Console.Write("-");
                    }
                }
                else if (szam1 > 0)
                {
                    for (int i = 1; i <= szam1; i++)
                    {
                        Console.Write("+");
                    }
                }

            } while (szam1 != 0);
            Console.WriteLine("Vége");



            Console.ReadKey();
        }
    }
}
