-- 1. feladat
CREATE DATABASE bovizu
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci

-- 2. feladat
CREATE TABLE folyok(
    nev varchar(15),
    vizhozam int,
    hossz int,
    magyar float
);

-- 3. feladat
INSERT INTO folyok(nev, vizhozam, hossz, magyar) VALUES
('Bodrog', 115, 115, 49),
('Duna', 6500, 2860, 417),
('Dráva', 670, 584, NULL),
('Hármas-Körös', 100, 360, 9.8),
('Maros', 155, 880, 49),
('Mura', 166, 749, NULL),
('Sajó', 70, 229, 127),
('Szamos', 120, 415, 50),
('Tisza', 820, 977, 597);


-- 4. feladat
UPDATE folyok 
SET hossz = 695
WHERE nev = 'Dráva'

-- 5. feladat
DELETE FROM folyok
WHERE vizhozam <= 100

-- 6. feladat
SELECT *
FROM `folyok`

-- 7. feladat

DROP DATABASE bovizu
