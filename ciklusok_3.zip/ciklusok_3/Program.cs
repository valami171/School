﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ciklusok_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();


            Console.Write("Adj meg egy számot, hogy menyiszer fusson le a ciklus: ");
            int szam = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("pozitív\t\tnulla\t\tnegatív");
            int i = 0;
            while (i != szam)
            {
                int random_szam = r.Next(-50, 50);
                if (random_szam == 0)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("\t\t" + random_szam);
                }
                else if (random_szam > 0)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(random_szam);
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("\t\t\t\t" + random_szam);
                   
                }
                i++;
            }




            Console.ReadKey();
        }
    }
}
