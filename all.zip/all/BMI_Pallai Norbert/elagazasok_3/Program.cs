﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace elagazasok_3
{
    class Program
    {
        static void Main(string[] args)
        {
            // BMi számítás
            Console.Write("Add meg a testsúlyod: ");
            double kg = Convert.ToInt32(Console.ReadLine());
            Console.Write("Add meg a magasságod centiméterben: ");
            int cm = Convert.ToInt32(Console.ReadLine());

            double BMI = kg / Math.Pow((double)cm / 100, 2);
            Console.WriteLine($"{BMI:f1}");

            if (BMI < 16)
            {
                Console.WriteLine("súlyos soványság");
            }
            else if (BMI > 16 && BMI < 16.99)
            {
                Console.WriteLine("mérsékelt soványság");
            }
            else if (BMI > 17 && BMI < 18.49)
            {
                Console.WriteLine("enyhe soványság");
            }
            else if (BMI > 18.5 && BMI < 24.99)
            {
                Console.WriteLine("normális testsúly");
            }
            else if (BMI > 25 && BMI < 29.99)
            {
                Console.WriteLine("túlsúlyos");
            }
            else if (BMI > 30 && BMI < 34.99)
            {
                Console.WriteLine("I. fokozatú elhízás");
            }
            else if (BMI > 35 && BMI < 39.99)
            {
                Console.WriteLine("II. fokozatú elhízás");
            }
            else if (BMI <= 40)
            {
                Console.WriteLine("III. fokozatú elhízás");
            }




            Console.ReadKey();
        }
    }
}
