﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lotto
{
    class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Lottószámok");
            // véletlenszám generálása

            // r.Next(1, 7) -csak 1,2, alsőérték, felsőérték-1 [alsó, felső)
            /*
             Console.WriteLine(r.Next(1, 91));
            Console.WriteLine(r.Next(1, 91));
            Console.WriteLine(r.Next(1, 91));
            Console.WriteLine(r.Next(1, 91));
            Console.WriteLine(r.Next(1, 91));
             */



            /*
              for (int i = 1; i <= 5; i++)
             {
                 Console.WriteLine(i + ". ---> " +r.Next(1, 91));
             }
             */


            // szam = r.Next(1, 11);
            // Console.WriteLine("A generált szám: " + szam);
            /*
            const int ALSO = 1;
            const int FELSO = 10;
            szam = r.Next(ALSO, FELSO+1);
            */

            /*
            Random r = new Random();

            int szam, tipp;
            szam = r.Next(1, 101);

            bool igaz = true;
            int db = 1;
            while (igaz && db!= 5)
            {
                Console.Write("Add meg a tipped: ");
                tipp = Convert.ToInt32(Console.ReadLine());

                if (szam == tipp)
                {
                    Console.WriteLine($"Gratulálok! {db} találatból eltaláltad a számot!");
                    igaz = false;
                }
                else if (szam > tipp)
                {
                    Console.WriteLine("Nagyobb");
                    db += 1;
                }
                else if (szam < tipp)
                {
                    Console.WriteLine("Kisebb");
                    db += 1;
                }
            }
            */

            Console.WriteLine("Rulett");
            // Nulla: 0
            // Páratlan: 1
            // Páros: 2

            Random r = new Random();
            int szam, tipp;
            szam = r.Next(0, 91);
            Console.WriteLine("Nulla: 0, Páratlan: 1, Páros: 2");
            Console.Write("Tippelj: ");
            tipp = Convert.ToInt32(Console.ReadLine());

            int fabatka = 10;

            while(fabatka != 0)
            {
                Console.Write("Tippelj: ");
                bool igaz = true;
                while (igaz)
                {
                    if (tipp > 2 || tipp < 0)
                    {
                        Console.WriteLine("Nem értelmezhető.");
                        igaz = false;

                    }
                    else if (szam == 0 && tipp == 0)
                    {
                        fabatka += 2;
                        Console.WriteLine($"Nyertél nullával. A szám: {szam} --- tipp: {tipp} --- fabatka: {fabatka}");
                        igaz = false;

                    }
                    else if (szam % 2 != 0 && tipp == 1)
                    {
                        fabatka += 2;
                        Console.WriteLine($"Nyertél páratlannal. A szám: {szam} --- tipp: {tipp} --- fabatka: {fabatka}");
                        igaz = false;

                    }
                    else if (szam % 2 == 0 && tipp == 2)
                    {
                        fabatka += 2;
                        Console.WriteLine($"Nyertél párossal. A szám: {szam} --- tipp: {tipp} --- fabatka: {fabatka}");
                        igaz = false;

                    }
                    else
                    {
                        fabatka -= 1;
                        Console.WriteLine($"Vesztettél. A szám: {szam} --- tipp: {tipp} --- fabatka: {fabatka}");
                        igaz = false;
                    }
                }
                
            }
            
            


            Console.ReadKey();
        }
    }
}
