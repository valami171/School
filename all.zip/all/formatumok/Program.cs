﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace formatumok
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"Fizetés: {687256:c2}");
            Console.WriteLine($"Fizetés: {687256/384.73} EUR");
            Console.WriteLine($"Fizetés: {687256 / 384.73: f2} EUR");
            Console.WriteLine($"Áfa: {0.25:p0}");


            Console.BackgroundColor = ConsoleColor.Red;
            Console.ForegroundColor= ConsoleColor.Gray;
            Console.WriteLine($"{"Kalapács János",15} {200000.12:c0}");
            Console.BackgroundColor = ConsoleColor.Green;
            Console.ForegroundColor= ConsoleColor.Black;
            Console.WriteLine($"{"Dugovics Tícián",-15} {32000.12:c0}");


            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            /*Budapest - Szeged távolsága: 210 km*/
            Console.WriteLine("a) Ha 130 km/óra sebességgel autózunk mennyi idő alatt érünk le?");
            double tavolsag = 210, sebesseg = 130;
            Console.WriteLine($"{tavolsag / sebesseg:f2} óra alatt érünk le Szegedre.");
            Console.WriteLine("b) Ha 1 óra 50 percünk van az út megtételére akkor milyen sebességgel kell autóznunk?");


            Console.ReadKey();
        }
    }
}
