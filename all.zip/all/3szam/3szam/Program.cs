﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3szam
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("----- A 3 szám közül melyik a legnagyobb? -----");

            Console.Write("Add meg az első számot: ");
            int szam1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Add meg a második számot: ");
            int szam2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Add meg a harmadik számot: ");
            int szam3 = Convert.ToInt32(Console.ReadLine());

            if (szam1 > szam2 && szam1 > szam3)
            {
                Console.WriteLine($"{szam1} nagyobb, mint {szam2} és {szam3}");
            }
            else if(szam2 > szam1 && szam2 > szam3)
            {
                Console.WriteLine($"{szam2} nagyobb, mint {szam1} és {szam3}");
            }
            else if (szam3 > szam1 && szam3 > szam2)
            {
                Console.WriteLine($"{szam3} nagyobb, mint {szam1} és {szam2}");
            }
            else if(szam1 == szam2)
            {
                Console.WriteLine($"Az első szám {szam1} egyenlő a második számmal {szam2}.");
            }
            else if (szam1 == szam3)
            {
                Console.WriteLine($"Az első szám {szam1} egyenlő a harmadik számmal {szam3}.");
            }
            else if (szam2 == szam3)
            {
                Console.WriteLine($"A második szám {szam1} egyenlő a harmadik számmal {szam2}.");
            }

            Console.ReadKey();
        }
    }
}
