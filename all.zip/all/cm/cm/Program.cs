﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cm
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Add meg a magasságot centiméterben: ");
            Single magassag = Convert.ToSingle(Console.ReadLine());
            Single meter = magassag / 100;
            Console.WriteLine($"{magassag} cm {meter} méter magas.");

            Console.ReadKey();

        }
    }
}