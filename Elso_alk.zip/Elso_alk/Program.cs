﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Elso_alk
{
    class Program
    {
        static void Main(string[] args)
        {
            // Console.WriteLine("Hello világ!");
            // Console.ReadKey();

            /*Console.Write("11.E!");
            Console.Write("Ez az első program.");
            Console.ReadLine();*/

            Console.WriteLine("Elemi adattípusok");
            Console.WriteLine("----------------------------------");


             byte letszam = 17;
            Console.WriteLine("Az osztály létszáma: " + letszam);

            // byte, sbyte (1 byte)
            Console.WriteLine("byte " +byte.MinValue + "->" + byte.MaxValue);
            Console.WriteLine("byte " + sbyte.MinValue + "->" + sbyte.MaxValue);

            // ushort, short (2 byte)
            Console.WriteLine("short:" + short.MinValue + "->" + short.MaxValue);
            Console.WriteLine("ushort:" + ushort.MinValue + "->" + ushort.MaxValue);


            /*sbyte goszt = 18 - 23;
            Console.WriteLine(goszt);*/

            // int, uint (4 byte)
            Console.WriteLine("int:" + int.MinValue + "->" + int.MaxValue);
            Console.WriteLine("uint:" + uint.MinValue + "->" + uint.MaxValue);


            // long, ulong (8 byte)
            Console.WriteLine("long: " + long.MinValue + "->" + long.MaxValue);
            Console.WriteLine("ulong: " + ulong.MinValue + "->" + ulong.MaxValue);


            /*
             byte ar1= 132;
            const ushort ALMAAR = 320;
            Console.Write("Hány kiló almát cásároltál?: ");
            string seged = Console.ReadLine();
            byte kg = Convert.ToByte(seged);
            int osszar = ALMAAR * kg;

            // rövidebben --> byte kg = Convert.ToByte(Console.ReadLine());
            Console.WriteLine($"A(z) {kg} kg alma ára: {ALMAAR*kg}");
             */




            // egész számokkal végezhető műveletek
            // +, -, *, /, % (maradék képzés)
            // két szám beolvasása: a, b

            byte a = Convert.ToByte(Console.ReadLine());
            byte b = Convert.ToByte(Console.ReadLine());
           /*
            Console.WriteLine("összedava:" + (a + b));
            Console.WriteLine("kivonás:" + (a - b));
            Console.WriteLine("szorozva:" + a * b);
            Console.WriteLine("osztva:" + a / b);
            Console.WriteLine("maradék:" + a % b);
             */


            Console.WriteLine("1. feladat ---- osztható 2-vel");
            if (a % 2 == 0)
            {
                Console.WriteLine($"{a} szám osztahtó 2-vel");
            }
            else
            {
                Console.WriteLine($"{a} szám nem osztahtó 2-vel");
            }


            Console.WriteLine("2. feladat ---- osztható 3-mal");
            if (b % 3 == 0)
            {
                Console.WriteLine($"{b} szám osztahtó 3-mal");
            }
            else
            {
                Console.WriteLine($"{b} szám nem osztahtó 3-mal");
            }


            Console.WriteLine("3. feladat ---- van-e maradék");
            if (a % b == 0)
            {
                Console.WriteLine($"{a} és {b} maradék nélüli");
            }
            else
            {
                Console.WriteLine($"{a} és {b} maradékos és a maradék {a%b}");
            }


            // valós számok
            // real (4 byte), double (8 byte)
            Console.WriteLine("single " + Single.MinValue + "->" + Single.MaxValue);
            Console.WriteLine("double " + double.MinValue + "->" + double.MaxValue);
            // double ddd = Convert.ToDouble();

            double ered = 10 / 3.0;
            Console.WriteLine("ered:" + ered);

            //logikai
            bool porszivozva = true;
            bool szemet_le = true;
            bool csoki = porszivozva && szemet_le;

            Console.WriteLine($"{porszivozva} és {szemet_le} eredménye: {csoki}");

            Console.ReadKey();
        }
    }
}
