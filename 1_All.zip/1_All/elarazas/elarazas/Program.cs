﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace elarazas
{
    class Program
    {
        static void Main(string[] args)
        {
            int szam1, szam2;
            Console.Write("Adj meg egy számot: ");
            szam1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Adj meg még egy számot: ");
            szam2 = Convert.ToInt32(Console.ReadLine());

            if (szam1 > szam2)
                Console.WriteLine(szam1 + " nagyobb mint " + szam2);
            else if (szam2 > szam1)
                Console.WriteLine(szam2 + " nagyobb mint " + szam1);
            else
                Console.WriteLine($"{szam1} és {szam2} egyenlő.");

            Console.ReadKey();
        }
    }
}
