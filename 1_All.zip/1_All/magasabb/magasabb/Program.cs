﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace magasabb
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("---- Ki a magasabb? ----");
            Console.Write("Adj meg egy nevet: ");
            string nev1 = Console.ReadLine();

            Console.Write("Adj meg még egy nevet: ");
            string nev2 = Console.ReadLine();



            Console.Write($"Add meg {nev1} magasságát cm-ben: ");
            Single mag1 = Convert.ToSingle(Console.ReadLine());

            Console.Write($"Add meg {nev2} magasságát cm-ben: ");
            Single mag2 = Convert.ToSingle(Console.ReadLine());


            if (mag1 > mag2)
            {
                Console.WriteLine($"{nev1} ({mag1/100} m) magasabb, mint {nev2} ({mag2 / 100} m).");
            }
            else if (mag1 < mag2)
            {
                Console.WriteLine($"{nev2} ({mag2 / 100} m) magasabb, mint {nev1} ({mag1 / 100} m).");
            }
            else
            {
                Console.WriteLine($"{nev1} ({mag1 / 100} m) ugyanolyan magas, mint {nev2} ({mag2 / 100} m).");
            }

                Console.ReadKey();
        }
    }
}
