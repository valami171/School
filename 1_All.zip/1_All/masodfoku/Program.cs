﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace masodfoku
{
    class Program
    {
        static void Main(string[] args)
        {
            // Másodfokú egyenlet
            double a, b, c;

            Console.Write("Add meg az a értéket: ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Add meg a b értéket: ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("Add meg a c értéket: ");
            c = Convert.ToInt32(Console.ReadLine());

            double D = Math.Pow(b,2)-(4*a*c);
            double keplet1 = (-b + D) / 2 * a;
            double keplet2 = (-b - D) / 2 * a;

            Console.WriteLine($"Az x1 = {keplet1}, az x2 = {keplet2}");

            Console.ReadKey();
        }
    }
}
