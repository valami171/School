﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mozi
{
    class Program
    {
        static void Main(string[] args)
        {
            int penz = 5000, jegy_ar = 1200, ember;
            Console.Write("Hányan szeretnétel moziba menni? ");
            ember = Convert.ToInt32(Console.ReadLine());

            if (penz > jegy_ar*ember)
                Console.WriteLine($"{penz:c0}-ból {ember} ember tud elmenni {ember*jegy_ar:c0}-ért.");
            else if (penz < jegy_ar * ember)
                Console.WriteLine("Sajnos a pénzből nem tudtok elmenni moziba.");

            Console.ReadKey();
        }
    }
}
