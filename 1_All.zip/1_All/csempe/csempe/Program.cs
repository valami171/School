﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csempe
{
    class Program
    {
        static void Main(string[] args)
        {
            const int csempe_sz = 60;
            const int csempe_m = 45;
            const int doboz_db = 8;
            const int doboz_ar = 9800;

            Console.Write("Kérem a helyég szélességét m-ben: ");
            double szel = Convert.ToDouble(Console.ReadLine());
            szel = szel * 100;

            Console.Write("Kérem a helyég magasságát m-ben: ");
            double mag = Convert.ToDouble(Console.ReadLine());
            mag = mag * 100;

            int sor_db = (int)szel / csempe_sz;

            if (!((int)szel % csempe_sz == 0))
            {
                sor_db++;
            }

            Console.WriteLine("Egy sorba rakandó csempék száma: " + sor_db + " db.");







            Console.ReadKey();
        }
    }
}
