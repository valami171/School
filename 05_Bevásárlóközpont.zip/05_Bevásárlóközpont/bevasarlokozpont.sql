-- 1. feladat
CREATE DATABASE bevasarlokozpontok
DEFAULT CHARACTER SET utf8
COLLATE utf8_hungarian_ci;

-- 2. feladat
CREATE TABLE plazak(
    nev varchar(20),
    irszam varchar(4),
    varos varchar(10),
    cim varchar(30),
    telszam varchar(15)
);

-- 3. feladat
INSERT INTO plazak(nev, irszam, varos, cim, telszam) VALUES
('Arena Mall', "1087", 'Budapest', 'Kerepesi út 9', '+3618807010'),
('Árkád Budapest', "1106", 'Budapest', 'Örs vezér tere 25/A', '+3614331400'),
('ÁRKÁD Győr', "9027", 'Győr', 'Budai út 1', '+3696555000'),
('Asia Center', "1152", 'Budapest', 'Szentmihályi út 167-169', '+3616888823'),
('Corvin Plaza', "1083", 'Budapest', 'Futó utca 37-45', '+3619777779'),
('Győr Plaza', "9024", 'Győr', 'Vasvári Pál út 1/A', '+3696410280'),
('KÖKI Terminál', "1191", 'Budapest', 'Vak Bottyán utca 75 A-C', '+3619191333'),
('Lurdy', "1097", 'Budapest', 'Könyves Kálmán krt. 12-14', '+36706742921'),
('Mamut', "1024", 'Budapest', 'Lövőház utca 2-6', '+36724580000'),
('Mom Park', "1123", 'Budapest', 'Alkotás utca 53', '+3614875500'),
('Napfény Park', "6729", 'Szolnok', 'Szabadkai út 7', NULL),
('Pécs Plaza', "7632", 'Pécs', 'Megyeri út 76', '+3672529329'),
('Shopmark', "1191", 'Budapest', 'Üllői út 201', '+367208239645'),
('West End', "1062", 'Budapest', 'Váci út 1-3', '+36203698503');

-- 4. feladat
UPDATE plazak
SET varos = "Szeged"
WHERE varos = "Szolnok";

-- 5. feladat
SELECT *
FROM `plazak`;

-- 6. feladat
SELECT nev
FROM plazak
WHERE varos NOT LIKE "Budapest";

-- 7. feladat
SELECT nev, varos
FROM plazak
WHERE telszam IS NOT NULL;

-- 8. feladat
DELETE FROM plazak
WHERE varos = "Győr";